// Minimal service worker: makes FixMe installable as a PWA without adding
// any caching surprises. Network-first for everything, no offline shell yet.
self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  // Pass through to the network. Present so the app meets PWA install
  // criteria (a fetch handler is required); caching comes later.
  if (event.request.method !== "GET") return;
  event.respondWith(
    fetch(event.request).catch(() => new Response("offline", { status: 503 }))
  );
});
