"use client";

import { useEffect, useState } from "react";
import { TriangleAlert, TrendingUp, Info, Sparkles } from "lucide-react";
import { getPatternInsights, type InsightsResult } from "@/app/actions/ai";
import { cn } from "@/lib/utils";

const KIND_ICON = {
  warn: TriangleAlert,
  win: TrendingUp,
  info: Info,
} as const;

export default function InsightsClient({ compact = false }: { compact?: boolean }) {
  const [res, setRes] = useState<InsightsResult | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    getPatternInsights()
      .then(setRes)
      .catch(() => setFailed(true));
  }, []);

  if (failed) return null;

  return (
    <section className={cn(compact ? "" : "mt-20")}>
      {!compact && (
        <>
          <h2 className="font-hand text-4xl font-semibold text-ink">
            what the data keeps saying
          </h2>
          <p className="mt-1 text-sm text-muted">
            patterns computed from your own logs — not generic advice, your
            numbers doing the talking.
          </p>
        </>
      )}

      <div className={cn("grid gap-4 md:grid-cols-3", compact ? "mt-4" : "mt-6")}>
        {(res?.insights ?? []).slice(0, compact ? 6 : 4).map((ins, idx) => {
          const Icon = KIND_ICON[ins.kind];
          return (
            <div
              key={ins.id}
              className={cn(
                "card card-hover p-5",
                idx === 1 && !compact && "md:-rotate-[0.6deg]"
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <Icon
                  size={16}
                  className={cn(
                    "mt-1 shrink-0",
                    ins.kind === "warn" ? "text-hl" : ins.kind === "win" ? "text-hl" : "text-faint"
                  )}
                />
                {ins.stat && (
                  <span className="text-3xl font-bold tracking-tight text-hl">
                    {ins.stat}
                  </span>
                )}
              </div>
              <h3 className="mt-2 text-[15px] font-semibold text-ink">
                {ins.headline}
              </h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-muted">
                {ins.body}
              </p>
            </div>
          );
        })}

        {!res && (
          <div className="card col-span-full flex items-center gap-3 p-6 text-sm text-muted">
            <span className="loading-dot h-1.5 w-1.5 rounded-full bg-hl" />
            <span className="loading-dot h-1.5 w-1.5 rounded-full bg-hl" />
            <span className="loading-dot h-1.5 w-1.5 rounded-full bg-hl" />
            <span className="ml-1">reading your logs…</span>
          </div>
        )}
      </div>

      {res?.narrative && (
        <div className="paper-note tilt-r mx-auto mt-8 max-w-xl p-6">
          <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold tracking-wide text-[#6f6435]">
            <Sparkles size={12} /> coach read
          </p>
          <p className="font-hand text-[23px] leading-snug">{res.narrative}</p>
        </div>
      )}
    </section>
  );
}
