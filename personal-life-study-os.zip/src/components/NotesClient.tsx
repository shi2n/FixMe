"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Plus, Trash2, FileText, BrainCircuit, Check } from "lucide-react";
import {
  getNotes,
  createNote,
  updateNote,
  deleteNote,
} from "@/app/actions/logs";
import { cn, fmtDate, fmtTime } from "@/lib/utils";
import type { NoteData } from "@/lib/types";

export default function NotesClient() {
  const [notes, setNotes] = useState<NoteData[]>([]);
  const [tab, setTab] = useState<"note" | "practice">("note");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle");
  const dirtyRef = useRef(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async () => {
    const list = await getNotes();
    setNotes(list);
    return list;
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const visible = notes.filter((n) => n.kind === tab);
  const selected = notes.find((n) => n.id === selectedId) ?? null;

  const select = (n: NoteData) => {
    setSelectedId(n.id);
    setTitle(n.title);
    setContent(n.content);
    dirtyRef.current = false;
    setSaveState("idle");
  };

  const add = async () => {
    const list = await createNote(tab);
    setNotes(list);
    const fresh = list.find((n) => n.kind === tab);
    if (fresh) select(fresh);
  };

  const scheduleSave = (id: number, t: string, c: string) => {
    dirtyRef.current = true;
    setSaveState("saving");
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      await updateNote(id, { title: t, content: c });
      dirtyRef.current = false;
      setSaveState("saved");
      const list = await getNotes();
      setNotes(list);
      setTimeout(() => setSaveState((s) => (s === "saved" ? "idle" : s)), 2000);
    }, 900);
  };

  const remove = async (id: number) => {
    const list = await deleteNote(id);
    setNotes(list);
    if (selectedId === id) {
      setSelectedId(null);
      setTitle("");
      setContent("");
    }
  };

  // group visible notes by day
  const groups: { date: string; items: NoteData[] }[] = [];
  for (const n of visible) {
    const d = n.updatedAt ? fmtDate(n.updatedAt.slice(0, 10)) : "";
    const g = groups.find((x) => x.date === d);
    if (g) g.items.push(n);
    else groups.push({ date: d, items: [n] });
  }

  return (
    <section className="mt-20">
      <h2 className="font-hand text-4xl font-semibold text-ink">
        notes &amp; practice space
      </h2>
      <p className="mt-1 text-sm text-muted">
        writing things down and testing yourself are different sports — both
        live here, timestamped, so nothing gets lost.
      </p>

      <div className="mt-6 flex gap-2">
        {(
          [
            { k: "note", label: "Notes", icon: FileText, hint: "write things down" },
            { k: "practice", label: "Practice", icon: BrainCircuit, hint: "test yourself" },
          ] as const
        ).map((t) => (
          <button
            key={t.k}
            onClick={() => setTab(t.k)}
            className={cn(
              "flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all",
              tab === t.k
                ? "bg-hl text-[#1c1c1b]"
                : "border border-line bg-card text-muted hover:text-ink"
            )}
          >
            <t.icon size={15} />
            {t.label}
            <span className="hidden text-[11px] font-normal opacity-70 sm:inline">
              — {t.hint}
            </span>
          </button>
        ))}
      </div>

      {tab === "practice" && (
        <p className="mt-4 max-w-xl font-hand text-[22px] leading-snug text-ink">
          blank page. write the answer from memory — then check yourself. the
          struggle is the studying.
        </p>
      )}

      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,4fr)_minmax(0,8fr)]">
        {/* list */}
        <div className="card max-h-[520px] overflow-y-auto p-4">
          <button onClick={add} className="btn-ghost w-full !py-2.5 text-sm">
            <Plus size={15} /> new {tab === "note" ? "note" : "practice entry"}
          </button>
          {groups.length === 0 && (
            <p className="mt-4 px-2 text-[13px] text-faint">
              nothing here yet. first entry is one click up.
            </p>
          )}
          {groups.map((g) => (
            <div key={g.date} className="mt-4">
              <p className="px-2 text-[11px] font-semibold tracking-wide text-faint">
                {g.date}
              </p>
              <div className="mt-1 space-y-1">
                {g.items.map((n) => (
                  <div
                    key={n.id}
                    className={cn(
                      "group flex w-full items-center gap-1 rounded-lg px-2 py-2 text-left transition-colors",
                      selectedId === n.id ? "bg-card2" : "hover:bg-card2/60"
                    )}
                  >
                    <button
                      onClick={() => select(n)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <p
                        className={cn(
                          "truncate text-[13px] font-medium",
                          selectedId === n.id ? "text-hl" : "text-ink"
                        )}
                      >
                        {n.title.trim() || "untitled"}
                      </p>
                      <p className="truncate text-[11px] text-faint">
                        {n.content.trim().slice(0, 60) || "empty page"} ·{" "}
                        {n.updatedAt ? fmtTime(n.updatedAt) : ""}
                      </p>
                    </button>
                    <button
                      onClick={() => remove(n.id)}
                      className="rounded p-1 text-faint opacity-0 transition-all group-hover:opacity-100 hover:text-hl"
                      title="delete"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* editor */}
        <div className="card flex min-h-[420px] flex-col p-5">
          {selected ? (
            <>
              <div className="flex items-center justify-between gap-3">
                <input
                  className="min-w-0 flex-1 bg-transparent font-hand text-[26px] font-semibold text-ink outline-none placeholder:text-faint"
                  placeholder={
                    tab === "note" ? "title it something honest" : "what are you testing yourself on?"
                  }
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    scheduleSave(selected.id, e.target.value, content);
                  }}
                />
                <span className="flex shrink-0 items-center gap-1 text-[11px] text-faint">
                  {saveState === "saving" && "saving…"}
                  {saveState === "saved" && (
                    <>
                      <Check size={11} className="text-hl" /> saved
                    </>
                  )}
                </span>
              </div>
              <textarea
                className="mt-3 min-h-[320px] flex-1 resize-none bg-transparent text-[14px] leading-relaxed text-ink outline-none placeholder:text-faint"
                placeholder={
                  tab === "note"
                    ? "markdown-ish is fine. code snippets welcome. nobody's grading formatting."
                    : "close the source. write out how a SYN flood works / solve the problem / derive the thing — from memory. check afterwards and mark where you broke."
                }
                value={content}
                onChange={(e) => {
                  setContent(e.target.value);
                  scheduleSave(selected.id, title, e.target.value);
                }}
              />
            </>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
              <p className="font-hand text-2xl text-muted">
                pick a page on the left — or start a new one
              </p>
              <button onClick={add} className="btn-hl">
                <Plus size={15} /> new {tab === "note" ? "note" : "practice entry"}
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
