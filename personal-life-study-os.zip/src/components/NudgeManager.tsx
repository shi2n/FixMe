"use client";

import { useEffect } from "react";
import { getSettings } from "@/app/actions/settings";
import { getTodayStatus } from "@/app/actions/data";
import { getNudge } from "@/app/actions/ai";
import { timeToMinutes, todayStr } from "@/lib/utils";

type Kind = "study" | "cap" | "exercise" | "reading";

function firedKey(kind: Kind) {
  return `fixme-nudge:${todayStr()}:${kind}`;
}
function alreadyFired(kind: Kind): boolean {
  try {
    return localStorage.getItem(firedKey(kind)) === "1";
  } catch {
    return true;
  }
}
function markFired(kind: Kind) {
  try {
    localStorage.setItem(firedKey(kind), "1");
  } catch {
    /* ignore */
  }
}

async function tick() {
  if (typeof window === "undefined") return;
  if (!("Notification" in window) || Notification.permission !== "granted")
    return;

  const s = await getSettings();
  if (!s.nudgesEnabled) return;

  const st = await getTodayStatus();
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();

  const due: Kind[] = [];

  // Cap nudge: the honest ceiling was reached — tell them to stop.
  if (
    s.capNudges &&
    st.capacityMinutes > 0 &&
    st.studyMinutes >= st.capacityMinutes &&
    !alreadyFired("cap")
  ) {
    due.push("cap");
  } else if (
    s.studyNudgeTime &&
    (timeToMinutes(s.studyNudgeTime) ?? 9999) <= nowMin &&
    st.studyMinutes < Math.max(25, st.capacityMinutes * 0.34) &&
    !alreadyFired("study")
  ) {
    due.push("study");
  }

  if (
    s.exerciseNudgeTime &&
    (timeToMinutes(s.exerciseNudgeTime) ?? 9999) <= nowMin &&
    !st.exerciseDone &&
    !alreadyFired("exercise")
  ) {
    due.push("exercise");
  }

  if (
    s.readingNudgeTime &&
    (timeToMinutes(s.readingNudgeTime) ?? 9999) <= nowMin &&
    !alreadyFired("reading")
  ) {
    due.push("reading");
  }

  const kind = due[0];
  if (!kind) return;
  markFired(kind);

  const { message } = await getNudge(kind).catch(() => ({ message: "" }));
  const titles: Record<Kind, string> = {
    study: "FixMe — nothing logged yet",
    cap: "FixMe — that's the cap",
    exercise: "FixMe — move a little",
    reading: "FixMe — 10 pages?",
  };
  try {
    new Notification(titles[kind], {
      body: message || "FixMe checking in.",
      icon: "/icon-512.png",
      tag: `fixme-${kind}`,
    });
  } catch {
    /* some mobile browsers only allow SW notifications */
  }
}

export default function NudgeManager() {
  useEffect(() => {
    let alive = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const loop = () => {
      tick()
        .catch(() => {})
        .finally(() => {
          if (alive) timer = setTimeout(loop, 90_000);
        });
    };
    const first = setTimeout(loop, 10_000);
    return () => {
      alive = false;
      clearTimeout(first);
      if (timer) clearTimeout(timer);
    };
  }, []);
  return null;
}
