"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Angry,
  Frown,
  Meh,
  Smile,
  Laugh,
  Zap,
  Check,
  PencilLine,
  RefreshCw,
  Sparkles,
  AlarmClock,
  HeartPulse,
} from "lucide-react";
import { getDashboard, saveCheckin, type DashboardData } from "@/app/actions/data";
import { getDailyCoach, type DailyCoachResult } from "@/app/actions/ai";
import { cn, fmtHours, fmtDateLong, todayStr } from "@/lib/utils";
import type { CheckinData } from "@/lib/types";

const MOODS = [
  { v: 1, icon: Angry, label: "awful" },
  { v: 2, icon: Frown, label: "low" },
  { v: 3, icon: Meh, label: "meh" },
  { v: 4, icon: Smile, label: "good" },
  { v: 5, icon: Laugh, label: "great" },
];

const ENERGY_LABELS = ["", "drained", "low", "okay", " solid", "wired"];

function CheckinForm({
  today,
  onSaved,
}: {
  today: CheckinData | null;
  onSaved: () => void;
}) {
  const [sleepHours, setSleepHours] = useState(today?.sleepHours ?? 7);
  const [bedtime, setBedtime] = useState(today?.bedtime ?? "");
  const [quality, setQuality] = useState(today?.sleepQuality ?? 3);
  const [mood, setMood] = useState(today?.mood ?? 0);
  const [energy, setEnergy] = useState(today?.energy ?? 0);
  const [emotionalLoad, setEmotionalLoad] = useState(today?.emotionalLoad ?? "");
  const [illness, setIllness] = useState(today?.illness ?? "");
  const [studyHrs, setStudyHrs] = useState(
    ((today?.studyMinutes ?? 0) / 60).toFixed(today?.studyMinutes ? 2 : 1)
  );
  const [exerciseDone, setExerciseDone] = useState(!!today?.exerciseDone);
  const [exerciseType, setExerciseType] = useState(today?.exerciseType ?? "");
  const [distraction, setDistraction] = useState(today?.distraction ?? "");
  const [saving, setSaving] = useState(false);
  const [savedTick, setSavedTick] = useState(false);

  const submit = async () => {
    setSaving(true);
    try {
      await saveCheckin({
        date: todayStr(),
        sleepHours: Number(sleepHours) || 0,
        bedtime: bedtime || "",
        sleepQuality: quality,
        mood: mood || null,
        energy: energy || null,
        emotionalLoad,
        illness,
        studyMinutes: Math.round((Number(studyHrs) || 0) * 60),
        exerciseDone,
        exerciseType,
        distraction,
      });
      setSavedTick(true);
      setTimeout(() => setSavedTick(false), 1600);
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label !text-[#6f6435]">slept (hours)</label>
          <input
            type="number"
            step="0.25"
            min="0"
            max="14"
            className="field-paper"
            value={sleepHours}
            onChange={(e) => setSleepHours(Number(e.target.value))}
          />
        </div>
        <div>
          <label className="label !text-[#6f6435]">went to bed at</label>
          <input
            type="time"
            className="field-paper"
            value={bedtime}
            onChange={(e) => setBedtime(e.target.value)}
          />
        </div>
      </div>

      <div>
        <label className="label !text-[#6f6435]">sleep quality</label>
        <div className="flex gap-1.5">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setQuality(n)}
              aria-label={`quality ${n}`}
              className={cn(
                "h-7 flex-1 rounded-md border border-transparent transition-all duration-150 hover:scale-110 active:scale-95",
                n <= quality ? "bg-[#3a3317]" : "bg-[#cbbc8d]"
              )}
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label !text-[#6f6435]">mood now</label>
          <div className="flex gap-1">
            {MOODS.map((m) => (
              <button
                key={m.v}
                type="button"
                title={m.label}
                onClick={() => setMood(m.v)}
                className={cn(
                  "flex-1 rounded-lg p-1.5 transition-all duration-200",
                  mood === m.v
                    ? "scale-110 bg-[#3a3317] text-[#f5d500] animate-pop"
                    : "text-[#8d7f52] hover:scale-110 hover:text-[#3a3317]"
                )}
              >
                <m.icon size={20} className="mx-auto" />
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="label !text-[#6f6435]">
            energy {energy ? `— ${ENERGY_LABELS[energy]}` : ""}
          </label>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                type="button"
                title={`energy ${n}`}
                onClick={() => setEnergy(n)}
                className={cn(
                  "flex-1 rounded-lg p-1.5 transition-all duration-200",
                  energy >= n
                    ? "scale-105 text-[#3a3317]"
                    : "text-[#c0b285] hover:text-[#3a3317]"
                )}
              >
                <Zap
                  size={18}
                  className="mx-auto"
                  fill={energy >= n ? "currentColor" : "none"}
                />
              </button>
            ))}
          </div>
        </div>
      </div>

      <div>
        <label className="label !text-[#6f6435]">
          anything heavy today? (private, optional)
        </label>
        <textarea
          rows={2}
          className="field-paper resize-none"
          placeholder="heartbreak, family stuff, anxiety… nobody sees this but you"
          value={emotionalLoad}
          onChange={(e) => setEmotionalLoad(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label !text-[#6f6435]">
            sick / in pain? (optional)
          </label>
          <input
            className="field-paper"
            placeholder="e.g. migraine"
            value={illness}
            onChange={(e) => setIllness(e.target.value)}
          />
        </div>
        <div>
          <label className="label !text-[#6f6435]">studied so far (h)</label>
          <input
            type="number"
            step="0.25"
            min="0"
            max="16"
            className="field-paper"
            value={studyHrs}
            onChange={(e) => setStudyHrs(e.target.value)}
          />
        </div>
      </div>

      <div className="flex items-end gap-3">
        <div>
          <label className="label !text-[#6f6435]">exercise?</label>
          <div className="flex gap-1.5">
            {[true, false].map((v) => (
              <button
                key={String(v)}
                type="button"
                onClick={() => setExerciseDone(v)}
                className={cn(
                  "rounded-lg px-3.5 py-1.5 text-sm font-semibold transition-all",
                  exerciseDone === v
                    ? "bg-[#3a3317] text-[#ece0af]"
                    : "bg-[#d9cb9b] text-[#6f6435] hover:bg-[#cfc08b]"
                )}
              >
                {v ? "yes" : "no"}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1">
          <label className="label !text-[#6f6435]">type</label>
          <input
            className="field-paper"
            placeholder="gym, run, walk…"
            value={exerciseType}
            onChange={(e) => setExerciseType(e.target.value)}
          />
        </div>
      </div>

      <div>
        <label className="label !text-[#6f6435]">
          what stole your attention today?
        </label>
        <input
          className="field-paper"
          placeholder="one honest word: youtube, phone, people…"
          value={distraction}
          onChange={(e) => setDistraction(e.target.value)}
        />
      </div>

      <button
        type="button"
        onClick={submit}
        disabled={saving}
        className={cn(
          "w-full rounded-xl bg-[#3a3317] py-3 text-sm font-bold text-[#ece0af] transition-all duration-300",
          savedTick
            ? "scale-[1.02] !bg-hl !text-[#1c1c1b]"
            : "hover:-translate-y-0.5 hover:shadow-[0_10px_24px_-10px_rgba(0,0,0,0.5)] active:translate-y-0"
        )}
      >
        {savedTick ? (
          <span className="inline-flex items-center gap-1.5">
            <Check size={16} strokeWidth={3} /> logged — capacity recalculating
          </span>
        ) : saving ? (
          "logging…"
        ) : (
          "log it — 30 seconds, done"
        )}
      </button>
    </div>
  );
}

function WeekChart({ week }: { week: DashboardData["week"] }) {
  const maxStudy = Math.max(60, ...week.map((w) => w.study));
  return (
    <div>
      <div className="flex h-24 items-end gap-[5px]">
        {week.map((w, i) => (
          <div key={w.date} className="group flex flex-1 flex-col items-center gap-1">
            <div
              className={cn(
                "w-full rounded-t-[4px] transition-all duration-300 group-hover:opacity-90",
                i === week.length - 1 ? "bg-hl" : "bg-card2 group-hover:bg-[#4a463c]"
              )}
              style={{ height: `${Math.max(3, (w.study / maxStudy) * 88)}px` }}
              title={`${w.date}: ${fmtHours(w.study)} study${w.sleep != null ? `, ${w.sleep}h sleep` : ""}`}
            />
          </div>
        ))}
      </div>
      <div className="mt-1 flex gap-[5px]">
        {week.map((w) => (
          <div key={w.date} className="flex-1 text-center text-[10px] text-faint">
            {w.label}
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-[5px]">
        {week.map((w, i) => (
          <div key={w.date} className="flex flex-1 justify-center">
            <span
              title={w.sleep != null ? `${w.sleep}h sleep` : "no sleep log"}
              className={cn(
                "inline-block rounded-full",
                i === week.length - 1 ? "bg-ink" : "bg-faint/70"
              )}
              style={{
                width: w.sleep != null ? 4 + Math.min(9, w.sleep) : 3,
                height: w.sleep != null ? 4 + Math.min(9, w.sleep) : 3,
                opacity: w.sleep != null ? 1 : 0.4,
              }}
            />
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-4 text-[11px] text-faint">
        <span className="flex items-center gap-1.5">
          <span className="inline-block h-2.5 w-2.5 rounded-sm bg-hl" /> study minutes
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block h-2 w-2 rounded-full bg-faint" /> sleep hours
        </span>
      </div>
    </div>
  );
}

export default function TodayClient() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [coach, setCoach] = useState<DailyCoachResult | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [spinning, setSpinning] = useState(false);

  const load = useCallback(async () => {
    try {
      const [d, c] = await Promise.all([getDashboard(), getDailyCoach()]);
      setData(d);
      setCoach(c);
      setErr(null);
    } catch {
      setErr("The notebook can't reach its database yet. Once it's awake, this fills in.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const refresh = async () => {
    setSpinning(true);
    await load();
    setEditing(false);
    setSpinning(false);
  };

  const today = data?.today ?? null;
  const cap = coach?.capacity ?? data?.capacity ?? null;
  const logged = today?.studyMinutes ?? 0;
  const pct = cap && cap.minutes > 0 ? Math.min(100, (logged / cap.minutes) * 100) : 0;
  const showForm = editing || !today;

  return (
    <section id="today" className="scroll-mt-24">
      <div className="flex items-end justify-between gap-4">
        <h2 className="font-hand text-4xl font-semibold text-ink">
          today <span className="text-faint">— {fmtDateLong(todayStr())}</span>
        </h2>
        <button
          onClick={refresh}
          className="btn-ghost !px-3 !py-2 text-xs"
          title="recompute"
        >
          <RefreshCw size={14} className={spinning ? "animate-spin" : ""} />
          recalc
        </button>
      </div>

      {err && (
        <p className="mt-4 rounded-xl border border-line bg-card p-4 text-sm text-muted">
          {err}
        </p>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        {/* check-in — the paper note */}
        <div className="paper-note tilt-l p-6">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-hand text-[26px] leading-none font-semibold">
              30 seconds of honesty
            </h3>
            {today && !editing && (
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#6f6435]">
                <Check size={13} strokeWidth={3} /> logged
              </span>
            )}
          </div>

          {showForm ? (
            <CheckinForm today={today} onSaved={refresh} />
          ) : (
            <div className="space-y-3">
              <p className="text-sm leading-relaxed">
                Slept <strong>{today.sleepHours ?? "?"}h</strong> (quality{" "}
                {today.sleepQuality ?? "?"}/5), mood {today.mood ?? "?"}/5,
                energy {today.energy ?? "?"}/5
                {today.exerciseDone
                  ? `, moved (${today.exerciseType || "yes"})`
                  : ", no exercise yet"}
                . Studied <strong>{fmtHours(today.studyMinutes)}</strong> so far.
              </p>
              {!!today.emotionalLoad?.trim() && (
                <p className="font-hand text-xl">heavy day — noted. be gentle.</p>
              )}
              <button
                onClick={() => setEditing(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#3a3317] px-3.5 py-2 text-xs font-bold text-[#ece0af] transition-transform hover:-translate-y-0.5"
              >
                <PencilLine size={13} /> edit today&apos;s log
              </button>
            </div>
          )}
        </div>

        {/* capacity engine */}
        <div className="space-y-6">
          <div className="card p-6">
            <div className="flex flex-wrap items-center gap-2">
              {cap?.mode === "recovery" && (
                <span className="chip !border-paper/40 !bg-paper !text-paper-ink font-semibold">
                  <HeartPulse size={12} /> recovery day
                </span>
              )}
              {cap?.mode === "push" && (
                <span className="chip !border-hl !bg-hl !text-[#1c1c1b] font-bold">
                  green light
                </span>
              )}
              {cap?.mode === "normal" && <span className="chip">normal day</span>}
              {coach?.aiPowered ? (
                <span className="chip !text-hl">
                  <Sparkles size={11} /> coach · live AI
                </span>
              ) : (
                <span className="chip" title="Add an AI key in Settings for live-phrased reads">
                  fallback rules — no AI key yet
                </span>
              )}
            </div>

            <div className="mt-4 flex items-end gap-3">
              <span className="text-6xl font-bold tracking-tight text-hl md:text-7xl">
                {cap ? cap.hours : "—"}
              </span>
              <span className="pb-2 text-sm text-muted">
                focused hours
                <br />
                <span className="font-hand text-xl text-ink">realistic today</span>
              </span>
            </div>

            {/* progress */}
            <div className="mt-4">
              <div className="flex justify-between text-[11px] text-faint">
                <span>logged {fmtHours(logged)}</span>
                <span>{cap ? `cap ${fmtHours(cap.minutes)}` : ""}</span>
              </div>
              <div className="mt-1 h-2 overflow-hidden rounded-full bg-bg-deep">
                <div
                  className={cn(
                    "h-full rounded-full transition-all duration-700",
                    pct >= 100 ? "bg-hl" : "bg-hl/80"
                  )}
                  style={{ width: `${pct}%` }}
                />
              </div>
              {pct >= 100 && (
                <p className="mt-1.5 font-hand text-lg text-hl">
                  cap hit. close the laptop — rest is scheduled work.
                </p>
              )}
            </div>

            <ul className="mt-4 space-y-1.5 text-[13px] leading-snug text-muted">
              {(cap?.reasons ?? []).slice(0, 5).map((r, i) => (
                <li key={i} className="flex gap-2">
                  <span className="text-hl">—</span>
                  <span>{r}</span>
                </li>
              ))}
            </ul>

            <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-line bg-bg-deep p-3.5">
              <AlarmClock size={16} className="mt-0.5 shrink-0 text-hl" />
              <p className="text-[13px] leading-snug text-muted">
                <span className="font-semibold text-ink">
                  Hardest work → {cap?.peak.window ?? "your peak window"}
                </span>{" "}
                ({cap?.peak.label ?? "chronotype pending"}). {cap?.peak.hint}
              </p>
            </div>

            <blockquote className="mt-4 border-l-[3px] border-hl pl-4">
              <p className="font-hand text-[22px] leading-snug text-ink">
                {coach?.message ?? data?.message ?? "checking the math…"}
              </p>
            </blockquote>
          </div>

          <div className="card p-6">
            <h3 className="font-hand text-[24px] font-semibold text-ink">
              last 14 days — study vs sleep
            </h3>
            <p className="mb-4 text-xs text-faint">
              tall bars are study minutes, dots are sleep hours. watch what short
              nights do to the bars.
            </p>
            {data ? (
              <WeekChart week={data.week} />
            ) : (
              <div className="h-24 rounded-lg bg-bg-deep" />
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
