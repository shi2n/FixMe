import { ChevronRight } from "lucide-react";

const METHODS: {
  name: string;
  oneLiner: string;
  when: string;
  how: string;
}[] = [
  {
    name: "Pomodoro Technique",
    oneLiner: "Focused sprints with real breaks — built into the clock above.",
    when: "Low motivation, a vague huge task, or a day that keeps slipping away.",
    how: "25 minutes on, 5 off, long break after 4 rounds. The break is part of the method, not a weakness. Start the clock, do one round, decide after.",
  },
  {
    name: "3-2-1 Method",
    oneLiner: "Read once, say it from memory twice, write it from memory once.",
    when: "Dense theory — crypto primitives, networking models, exam material for Security+.",
    how: "Three passes through three different channels (eyes, mouth, hand). Each pass forces a different kind of recall, which is exactly why it beats re-reading the same page three times.",
  },
  {
    name: "Active Recall",
    oneLiner: "Close the notes. Retrieve. That's the entire trick.",
    when: "Almost always. It's the mechanism underneath every other method on this list.",
    how: "Blank-page 'blurt': write everything you know about a topic, then compare against the source. The gaps you couldn't retrieve ARE your study plan. Use the Practice tab below for this.",
  },
  {
    name: "Feynman Technique",
    oneLiner: "Explain it like you're teaching a beginner. Jargon marks the gap.",
    when: "When you 'kind of get it' — subnets, TLS handshakes, a buffer overflow you followed but can't reproduce.",
    how: "Say the concept out loud in plain words. The exact spot where you stall or reach for jargon is the spot you don't understand. Go back and fix that one gap, then re-explain.",
  },
  {
    name: "Spaced Repetition (7-3-2-1)",
    oneLiner: "Review at growing intervals: 1 day, 2 days, 3 days, 7 days.",
    when: "Anything you need permanently — ports, flags, commands, crypto facts, cert material.",
    how: "Instead of cramming a topic five times in one night, touch it again tomorrow, then after 2 days, 3 days, 7. Each successful recall stretches the next interval. Boring, unbeatable.",
  },
  {
    name: "Interleaving",
    oneLiner: "Mix topics in one session instead of marinating in one for hours.",
    when: "Problem-type discrimination — which matters in CTFs and anything STEM: web vs crypto vs forensics in one sitting.",
    how: "Alternate related-but-different problems every ~30 minutes. It feels harder and messier than blocking — that difficulty is exactly what builds the 'which technique is this?' reflex.",
  },
];

export default function MethodsGuide() {
  return (
    <section className="mt-20">
      <h2 className="font-hand text-4xl font-semibold text-ink">
        study methods that actually work
      </h2>
      <p className="mt-1 text-sm text-muted">
        pick one per session — don&apos;t stack six techniques and call it a
        system.
      </p>

      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {METHODS.map((m, i) => (
          <details
            key={m.name}
            className={`method card card-hover group p-5 ${i === 4 ? "md:rotate-[0.5deg]" : ""}`}
          >
            <summary className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-[15px] font-semibold text-ink">{m.name}</h3>
                <p className="mt-1 text-[13px] leading-snug text-muted">
                  {m.oneLiner}
                </p>
              </div>
              <ChevronRight
                size={16}
                className="chev mt-1 shrink-0 text-faint group-hover:text-hl"
              />
            </summary>
            <div className="mt-3 space-y-2 border-t border-line pt-3 text-[13px] leading-relaxed">
              <p>
                <span className="font-semibold text-hl">when: </span>
                <span className="text-muted">{m.when}</span>
              </p>
              <p className="text-muted">{m.how}</p>
            </div>
          </details>
        ))}
      </div>
    </section>
  );
}
