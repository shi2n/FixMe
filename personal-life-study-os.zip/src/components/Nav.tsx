"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  NotebookPen,
  ShieldHalf,
  Briefcase,
  Wallet,
  TriangleAlert,
  BookOpen,
  Settings2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const links = [
  { href: "/", label: "Today", icon: NotebookPen },
  { href: "/skills", label: "Skills", icon: ShieldHalf },
  { href: "/career", label: "Career", icon: Briefcase },
  { href: "/finance", label: "Money", icon: Wallet },
  { href: "/mistakes", label: "Mistakes", icon: TriangleAlert },
  { href: "/reading", label: "Reading", icon: BookOpen },
  { href: "/settings", label: "Settings", icon: Settings2 },
];

export default function Nav() {
  const pathname = usePathname();
  return (
    <header className="sticky top-0 z-40 border-b border-line/70 bg-bg/85 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-2">
        <Link
          href="/"
          className="group relative inline-block shrink-0 font-hand text-[32px] leading-none font-semibold text-ink transition-colors hover:text-hl"
        >
          FixMe
          <svg
            className="absolute -bottom-1 left-0 w-full"
            viewBox="0 0 64 8"
            fill="none"
            aria-hidden
          >
            <path
              d="M2 6C18 2 30 7.6 44 5.2C52 3.7 58 4.6 62 3"
              stroke="#f5d500"
              strokeWidth="2.4"
              strokeLinecap="round"
            />
          </svg>
        </Link>
        <nav className="flex items-center gap-0.5 overflow-x-auto">
          {links.map((l) => {
            const active =
              l.href === "/" ? pathname === "/" : pathname.startsWith(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                className={cn(
                  "flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-[13px] font-medium whitespace-nowrap transition-all duration-200",
                  active
                    ? "text-hl shadow-[inset_0_-2px_0_0_rgba(245,213,0,0.9)]"
                    : "text-muted hover:-translate-y-px hover:text-ink"
                )}
              >
                <l.icon size={15} strokeWidth={active ? 2.5 : 2} />
                <span className="hidden md:inline">{l.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
