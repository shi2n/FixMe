import { ArrowDown, Timer } from "lucide-react";
import { fmtDateLong, todayStr } from "@/lib/utils";

export default function Hero() {
  return (
    <section className="relative pt-14 pb-16 md:pt-20">
      <p className="font-hand text-xl text-muted md:text-2xl">
        {fmtDateLong(todayStr())} — a notebook that tells you the truth
      </p>

      <h1 className="mt-4 max-w-3xl font-hand text-[54px] leading-[0.95] font-bold text-ink md:text-[88px]">
        Track the mess.
        <br />
        Then{" "}
        <span className="relative inline-block px-1">
          <span className="relative z-10">fix it.</span>
          <svg
            className="marker-draw pointer-events-none absolute -inset-x-3 -inset-y-2 z-0 h-[calc(100%+1rem)] w-[calc(100%+1.5rem)]"
            viewBox="0 0 320 120"
            fill="none"
            preserveAspectRatio="none"
            aria-hidden
          >
            <path
              pathLength={1}
              d="M160 14C84 8 14 26 12 57C10 90 86 108 168 106C250 104 308 84 306 51C304 22 226 8 144 14C96 17.6 60 26 44 38"
              stroke="#f5d500"
              strokeWidth="7"
              strokeLinecap="round"
            />
            <path
              pathLength={1}
              className="second"
              d="M28 70C60 98 160 116 236 100C272 92 298 78 302 60"
              stroke="#f5d500"
              strokeOpacity="0.35"
              strokeWidth="8"
              strokeLinecap="round"
            />
          </svg>
        </span>
      </h1>

      <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-muted">
        FixMe watches what you actually do — sleep, mood, energy, study, money,
        mistakes — and each morning tells you honestly what today can hold.
        Built for a cybersecurity student, not for a productivity influencer.
        No streaks worship, no guilt trips.
      </p>

      <div className="mt-8 flex flex-wrap items-center gap-3">
        <a href="#today" className="btn-hl">
          <ArrowDown size={16} />
          30-second check-in
        </a>
        <a href="#pomodoro" className="btn-ghost">
          <Timer size={16} />
          Start a focus round
        </a>
      </div>

      <aside className="paper-note tilt-r absolute top-16 right-0 hidden w-56 -rotate-1 p-5 lg:block">
        <p className="font-hand text-[22px] leading-snug">
          30 seconds of honesty a day. That&apos;s the whole admin budget.
        </p>
      </aside>
    </section>
  );
}
