export default function Footer() {
  return (
    <footer className="mt-24 border-t border-line/70">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-2.5 px-4 py-10">
        <p className="font-hand text-[26px] leading-none text-ink">
          made by <span className="text-hl">Shaizan Siddiqui</span>
        </p>
        <p className="text-sm text-muted">
          FixMe — private by design. No accounts, no tracking, no streak-shame.
          Keep the URL to yourself and it stays yours.
        </p>
        <p className="text-xs text-faint">
          Your AI key is stored encrypted on the server and never reaches the
          browser. Check-ins take 30 seconds; honesty is the whole trick.
        </p>
      </div>
    </footer>
  );
}
