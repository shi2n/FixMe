"use client";

import { useState } from "react";
import { Send, Database, KeyRound } from "lucide-react";
import Link from "next/link";
import { askData, type AskResult } from "@/app/actions/ai";
import { cn } from "@/lib/utils";

const SAMPLES = [
  "How much did I study last week?",
  "What usually causes my bad days?",
  "How consistent has my sleep been?",
  "What days do I focus best?",
  "What am I procrastinating on most?",
];

export default function AskDataClient() {
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<AskResult | null>(null);
  const [asked, setAsked] = useState("");

  const ask = async (question: string) => {
    const questionTrimmed = question.trim();
    if (!questionTrimmed || busy) return;
    setBusy(true);
    setAsked(questionTrimmed);
    setRes(null);
    try {
      const out = await askData(questionTrimmed);
      setRes(out);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section id="ask" className="mt-20 scroll-mt-24">
      <h2 className="font-hand text-4xl font-semibold text-ink">
        ask your data
      </h2>
      <p className="mt-1 text-sm text-muted">
        the question goes to the AI together with your real logged rows — the
        answer comes from your life, not from a template.
      </p>

      <div className="card mt-6 p-6">
        <div className="flex gap-2.5">
          <textarea
            rows={1}
            className="field resize-none !py-3"
            placeholder='e.g. "how much did I actually study this month vs what I planned?"'
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                ask(q);
              }
            }}
          />
          <button
            onClick={() => ask(q)}
            disabled={busy || !q.trim()}
            className="btn-hl self-stretch !px-4"
          >
            <Send size={16} />
          </button>
        </div>

        <div className="mt-3 flex flex-wrap gap-1.5">
          {SAMPLES.map((s) => (
            <button
              key={s}
              onClick={() => {
                setQ(s);
                ask(s);
              }}
              className="chip transition-all hover:border-hl/50 hover:text-hl"
            >
              {s}
            </button>
          ))}
        </div>

        {(busy || res) && (
          <div className="mt-6 border-t border-line pt-5">
            {asked && (
              <p className="font-hand text-xl text-muted">&ldquo;{asked}&rdquo;</p>
            )}
            {busy ? (
              <p className="mt-3 flex items-center gap-2 text-sm text-muted">
                <span className="loading-dot h-1.5 w-1.5 rounded-full bg-hl" />
                <span className="loading-dot h-1.5 w-1.5 rounded-full bg-hl" />
                <span className="loading-dot h-1.5 w-1.5 rounded-full bg-hl" />
                <span className="ml-1">pulling your rows, thinking…</span>
              </p>
            ) : res?.needsKey ? (
              <div className="paper-note tilt-l mx-auto mt-4 max-w-md p-5">
                <p className="flex items-center gap-1.5 text-[11px] font-bold text-[#6f6435]">
                  <KeyRound size={12} /> no AI key connected yet
                </p>
                <p className="mt-1.5 font-hand text-[21px] leading-snug">
                  this brain needs your own OpenAI / Claude / Gemini key to
                  answer. 60 seconds in Settings and it works.
                </p>
                <Link
                  href="/settings"
                  className="mt-3 inline-block rounded-lg bg-[#3a3317] px-3.5 py-2 text-xs font-bold text-[#ece0af] transition-transform hover:-translate-y-0.5"
                >
                  open settings
                </Link>
              </div>
            ) : (
              <p className="mt-3 text-[15px] leading-relaxed whitespace-pre-wrap text-ink">
                {res?.answer}
              </p>
            )}
            {res?.groundedIn && !res.needsKey && (
              <p className="mt-4 flex items-center gap-1.5 text-[11px] text-faint">
                <Database size={11} /> grounded in: {res.groundedIn}
              </p>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
