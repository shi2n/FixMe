"use client";

import { useEffect, useRef, useState } from "react";
import { Play, Pause, RotateCcw, SkipForward, Check, Timer, BookOpenCheck } from "lucide-react";
import { addStudyMinutes } from "@/app/actions/data";
import { cn, todayStr } from "@/lib/utils";

type Phase = "focus" | "break" | "longBreak";
type Mode = "auto" | "manual";

function chime() {
  try {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(1174.66, ctx.currentTime + 0.16);
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 1.1);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 1.2);
  } catch {
    /* no audio */
  }
  try {
    navigator.vibrate?.(140);
  } catch {
    /* no vibration */
  }
}

function fmtClock(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function PomodoroClient() {
  const [mode, setMode] = useState<Mode>("auto");
  const [focusMin, setFocusMin] = useState(25);
  const [breakMin, setBreakMin] = useState(5);
  const [longMin, setLongMin] = useState(20);
  const [phase, setPhase] = useState<Phase>("focus");
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [round, setRound] = useState(0); // completed focus rounds today
  const [flash, setFlash] = useState<string | null>(null);
  const [loggedMin, setLoggedMin] = useState(0);
  const phaseRef = useRef(phase);
  phaseRef.current = phase;

  const minutesFor = (p: Phase) =>
    p === "focus" ? focusMin : p === "break" ? breakMin : longMin;
  const totalFor = (p: Phase) => minutesFor(p) * 60;

  // restore round count for today
  useEffect(() => {
    try {
      const raw = localStorage.getItem(`fixme-pomo:${todayStr()}`);
      if (raw) setRound(parseInt(raw, 10) || 0);
    } catch {
      /* ignore */
    }
  }, []);

  const persistRound = (r: number) => {
    try {
      localStorage.setItem(`fixme-pomo:${todayStr()}`, String(r));
    } catch {
      /* ignore */
    }
  };

  const setPhaseAndTimer = (p: Phase) => {
    setPhase(p);
    setSecondsLeft(totalFor(p));
  };

  const completePhase = async (finished: Phase) => {
    chime();
    if (finished === "focus") {
      const mins = minutesFor("focus");
      const nr = round + 1;
      setRound(nr);
      persistRound(nr);
      setLoggedMin((v) => v + mins);
      setFlash(`+${mins} min logged to today's study total`);
      setTimeout(() => setFlash(null), 3500);
      addStudyMinutes(mins).catch(() => {});
      const next: Phase = mode === "auto" && nr % 4 === 0 ? "longBreak" : "break";
      setPhase(next);
      setSecondsLeft(totalFor(next));
      setRunning(mode === "auto");
    } else {
      setPhaseAndTimer("focus");
      setRunning(mode === "auto");
    }
  };

  // countdown
  useEffect(() => {
    if (!running) return;
    const iv = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(iv);
          setTimeout(() => completePhase(phaseRef.current), 0);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  // document title
  useEffect(() => {
    document.title = running
      ? `${fmtClock(secondsLeft)} ${phase === "focus" ? "focus" : "break"} · FixMe`
      : "FixMe — track the mess, then fix it";
    return () => {
      document.title = "FixMe — track the mess, then fix it";
    };
  }, [running, secondsLeft, phase]);

  // editing durations while idle updates the clock
  const editDuration = (which: "focus" | "break" | "long", v: number) => {
    const val = Math.max(1, Math.min(120, Math.round(v) || 1));
    if (which === "focus") setFocusMin(val);
    else if (which === "break") setBreakMin(val);
    else setLongMin(val);
    if (!running) {
      if ((which === "focus" && phase === "focus") || (which === "break" && phase === "break") || (which === "long" && phase === "longBreak")) {
        setSecondsLeft(val * 60);
      }
    }
  };

  const total = totalFor(phase);
  const R = 86;
  const C = 2 * Math.PI * R;
  const frac = total > 0 ? secondsLeft / total : 0;

  const cyclePos = round % 4;
  const roundLabel =
    phase === "focus"
      ? `Round ${cyclePos + 1} of 4`
      : phase === "longBreak"
        ? "Long break — round 4 done"
        : `Break after round ${cyclePos === 0 ? 4 : cyclePos}`;

  const phaseHand =
    phase === "focus" ? "focus" : phase === "break" ? "break" : "long break";

  return (
    <section id="pomodoro" className="mt-20 scroll-mt-24">
      <h2 className="font-hand text-4xl font-semibold text-ink">
        the pomodoro clock
      </h2>
      <p className="mt-1 text-sm text-muted">
        Finished focus rounds log themselves into today&apos;s study hours. No
        double entry — the capacity engine sees it immediately.
      </p>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        {/* the clock */}
        <div className="card flex flex-col items-center p-8">
          <div className="relative">
            <svg width="220" height="220" viewBox="0 0 220 220">
              <circle
                cx="110"
                cy="110"
                r={R}
                fill="none"
                stroke="#333330"
                strokeWidth="11"
              />
              <circle
                cx="110"
                cy="110"
                r={R}
                fill="none"
                stroke="#f5d500"
                strokeWidth="11"
                strokeLinecap="round"
                strokeDasharray={C}
                strokeDashoffset={C * (1 - frac)}
                transform="rotate(-90 110 110)"
                className="ring-progress"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-bold tracking-tight tabular-nums">
                {fmtClock(secondsLeft)}
              </span>
              <span
                className={cn(
                  "font-hand text-2xl",
                  phase === "focus" ? "text-hl" : "text-muted"
                )}
              >
                {phaseHand}
              </span>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-1.5">
            {[0, 1, 2, 3].map((i) => (
              <span
                key={i}
                className={cn(
                  "h-2.5 w-2.5 rounded-full transition-colors duration-300",
                  i < (phase === "longBreak" ? 4 : cyclePos) ? "bg-hl" : "bg-card2"
                )}
              />
            ))}
            <span className="ml-2 text-xs text-faint">{roundLabel}</span>
          </div>

          <div className="mt-5 flex items-center gap-2.5">
            <button
              onClick={() => setRunning((r) => !r)}
              className="btn-hl min-w-32"
            >
              {running ? (
                <>
                  <Pause size={15} /> pause
                </>
              ) : (
                <>
                  <Play size={15} /> start {phase === "focus" ? "focus" : "break"}
                </>
              )}
            </button>
            <button
              onClick={() => {
                setRunning(false);
                setPhaseAndTimer(phase);
              }}
              className="btn-ghost !px-3"
              title="reset this phase"
            >
              <RotateCcw size={15} />
            </button>
            <button
              onClick={() => {
                setRunning(false);
                if (phase === "focus") {
                  setPhaseAndTimer("break");
                } else {
                  setPhaseAndTimer("focus");
                }
              }}
              className="btn-ghost !px-3"
              title="skip phase (not logged)"
            >
              <SkipForward size={15} />
            </button>
          </div>

          {flash && (
            <p className="mt-4 inline-flex animate-pop items-center gap-1.5 rounded-full bg-hl px-3.5 py-1.5 text-xs font-bold text-[#1c1c1b]">
              <Check size={13} strokeWidth={3} /> {flash}
            </p>
          )}
        </div>

        {/* settings */}
        <div className="card p-8">
          <div className="flex gap-2">
            {(["auto", "manual"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => {
                  setMode(m);
                  setRunning(false);
                }}
                className={cn(
                  "flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all",
                  mode === m
                    ? "bg-hl text-[#1c1c1b]"
                    : "border border-line bg-bg-deep text-muted hover:text-ink"
                )}
              >
                {m === "auto" ? "Automatic — 25/5 rhythm" : "Manual — my own rhythm"}
              </button>
            ))}
          </div>

          <div className="mt-6 grid grid-cols-3 gap-3">
            <div>
              <label className="label">focus (min)</label>
              <input
                type="number"
                className="field"
                min={5}
                max={120}
                value={focusMin}
                disabled={mode === "auto"}
                onChange={(e) => editDuration("focus", Number(e.target.value))}
              />
            </div>
            <div>
              <label className="label">break (min)</label>
              <input
                type="number"
                className="field"
                min={1}
                max={60}
                value={breakMin}
                onChange={(e) => editDuration("break", Number(e.target.value))}
              />
            </div>
            <div>
              <label className="label">long break</label>
              <select
                className="field"
                value={longMin}
                onChange={(e) => editDuration("long", Number(e.target.value))}
              >
                <option value={15}>15</option>
                <option value={20}>20</option>
                <option value={25}>25</option>
                <option value={30}>30</option>
              </select>
            </div>
          </div>

          <div className="mt-6 space-y-3 text-[13px] leading-relaxed text-muted">
            <p className="flex gap-2.5">
              <Timer size={15} className="mt-0.5 shrink-0 text-hl" />
              {mode === "auto"
                ? "Automatic runs the classic cycle: 25 focus, 5 break, and a long break after every 4th round. Phases start on their own."
                : "Manual keeps your custom lengths and waits for you to start each phase — for when 25 minutes feels wrong."}
            </p>
            <p className="flex gap-2.5">
              <BookOpenCheck size={15} className="mt-0.5 shrink-0 text-hl" />
              {loggedMin > 0
                ? `${loggedMin} minutes logged from this device today. They count toward your daily capacity — hit it and stop.`
                : "Finish a focus round and the minutes land in today's check-in automatically. Sound + a gentle tap mark each phase change."}
            </p>
          </div>

          <p className="mt-6 font-hand text-[22px] leading-snug text-ink">
            one round beats zero rounds. always.
          </p>
        </div>
      </div>
    </section>
  );
}
