import crypto from "node:crypto";

// AES-256-GCM encryption for the user's AI API key.
// The key is only ever stored encrypted, and only ever decrypted inside
// server-side code when making a provider call. It is never sent to the
// browser, never logged, and never returned by any action.

function secretKey(): Buffer {
  const src =
    process.env.FIXME_SECRET ||
    process.env.APP_SECRET ||
    `${process.env.DATABASE_URL ?? ""}|fixme-local-key-encryption`;
  return crypto.createHash("sha256").update(String(src)).digest();
}

export function encryptSecret(plain: string): string {
  const key = secretKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return ["v1", iv.toString("base64"), tag.toString("base64"), enc.toString("base64")].join(":");
}

export function decryptSecret(payload: string): string | null {
  try {
    const [ver, ivB64, tagB64, dataB64] = payload.split(":");
    if (ver !== "v1" || !ivB64 || !tagB64 || !dataB64) return null;
    const key = secretKey();
    const decipher = crypto.createDecipheriv(
      "aes-256-gcm",
      key,
      Buffer.from(ivB64, "base64")
    );
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    const dec = Buffer.concat([
      decipher.update(Buffer.from(dataB64, "base64")),
      decipher.final(),
    ]);
    return dec.toString("utf8");
  } catch {
    return null;
  }
}

export function maskKey(plain: string | null): string {
  if (!plain) return "";
  if (plain.length <= 8) return "••••••••";
  return `${plain.slice(0, 4)}…${plain.slice(-4)}`;
}
