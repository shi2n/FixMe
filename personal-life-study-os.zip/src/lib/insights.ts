import { fmtHours } from "./utils";
import type { CheckinLite } from "./capacity";
import { bedtimeStdMin } from "./capacity";

export interface Insight {
  id: string;
  kind: "warn" | "win" | "info";
  headline: string;
  body: string;
  stat?: string; // big number badge, e.g. "-40%"
}

export interface MistakeLite {
  date: string;
  category: string;
  cause: string;
}

function avg(nums: number[]): number {
  if (!nums.length) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

const DISTRACTION_KEYWORDS: [RegExp, string][] = [
  [/phone|scroll/i, "phone scrolling"],
  [/youtube|yt\b/i, "YouTube"],
  [/tik\s?tok/i, "TikTok"],
  [/instagram|insta|ig\b/i, "Instagram"],
  [/reddit/i, "Reddit"],
  [/discord/i, "Discord"],
  [/game|gaming|valorant|fortnite|minecraft|steam/i, "games"],
  [/netflix|series|tv\b|anime|movie/i, "streaming"],
  [/twitter|\bx\b/i, "X/Twitter"],
  [/whatsapp|messages|chat/i, "chatting"],
];

export function computeInsights(
  checkins: CheckinLite[],
  mistakes: MistakeLite[]
): Insight[] {
  const out: Insight[] = [];
  const days = checkins.filter((c) => c.studyMinutes != null);

  if (days.length >= 6) {
    // sleep < 6h vs >= 7h → study output difference
    const low = days.filter((d) => (d.sleepHours ?? 7) < 6);
    const high = days.filter((d) => (d.sleepHours ?? 0) >= 7);
    if (low.length >= 2 && high.length >= 2) {
      const a = avg(low.map((d) => d.studyMinutes ?? 0));
      const b = avg(high.map((d) => d.studyMinutes ?? 0));
      if (a < b * 0.95 && b > 0) {
        out.push({
          id: "sleep-output",
          kind: "warn",
          stat: `-${Math.round((1 - a / b) * 100)}%`,
          headline: "Short sleep taxes your output",
          body: `After under 6h you average ${fmtHours(a)} of study. After 7h+ you average ${fmtHours(b)}. The cheapest study technique you own is going to bed on time.`,
        });
      }
    }

    // mood low vs high
    const lowMood = days.filter((d) => (d.mood ?? 3) <= 2);
    const highMood = days.filter((d) => (d.mood ?? 3) >= 4);
    if (lowMood.length >= 2 && highMood.length >= 2) {
      const a = avg(lowMood.map((d) => d.studyMinutes ?? 0));
      const b = avg(highMood.map((d) => d.studyMinutes ?? 0));
      if (a < b * 0.92 && b > 0) {
        out.push({
          id: "mood-output",
          kind: "info",
          stat: `-${Math.round((1 - a / b) * 100)}%`,
          headline: "Rough moods cost you real hours",
          body: `On low-mood days you put in ${fmtHours(a)} vs ${fmtHours(b)} on good ones. That's not weakness — it's signal. Plan lighter, recall-style work for those days in advance.`,
        });
      }
    }

    // best weekday
    const byDay = new Map<number, number[]>();
    for (const d of days) {
      const wd = new Date(`${d.date}T00:00:00`).getDay();
      if (!byDay.has(wd)) byDay.set(wd, []);
      byDay.get(wd)!.push(d.studyMinutes ?? 0);
    }
    const names = ["Sundays", "Mondays", "Tuesdays", "Wednesdays", "Thursdays", "Fridays", "Saturdays"];
    let best = -1;
    let bestAvg = 0;
    byDay.forEach((mins, wd) => {
      if (mins.length >= 2) {
        const a = avg(mins);
        if (a > bestAvg) {
          bestAvg = a;
          best = wd;
        }
      }
    });
    if (best >= 0 && bestAvg >= 45) {
      out.push({
        id: "best-day",
        kind: "win",
        stat: fmtHours(bestAvg),
        headline: `${names[best]} are your engine days`,
        body: `You average ${fmtHours(bestAvg)} on ${names[best]}. Schedule the hardest material — new lab, new exploit technique — there on purpose.`,
      });
    }

    // distraction leaks
    const tally = new Map<string, number>();
    for (const d of days) {
      const note = d.distraction ?? "";
      if (!note) continue;
      for (const [re, label] of DISTRACTION_KEYWORDS) {
        if (re.test(note)) tally.set(label, (tally.get(label) ?? 0) + 1);
      }
    }
    const top = [...tally.entries()].sort((a, b) => b[1] - a[1])[0];
    if (top && top[1] >= 2) {
      out.push({
        id: "distraction",
        kind: "warn",
        stat: `${top[1]}×`,
        headline: `Your #1 leak: ${top[0]}`,
        body: `It shows up in ${top[1]} of your distraction notes. Don't negotiate with it mid-session — kill it at the environment level (other room, blocker, greyscale) before the session starts.`,
      });
    }
  }

  // bedtime consistency
  const std = bedtimeStdMin(checkins);
  if (std != null && std > 80) {
    out.push({
      id: "consistency",
      kind: "warn",
      stat: `±${std}m`,
      headline: "Your bedtime keeps drifting",
      body: `Night-to-night your bedtime swings about ${std} minutes. Consistency beats duration — a fixed lights-out time does more for focus than an occasional 9-hour catch-up.`,
    });
  }

  // mistake patterns
  if (mistakes.length >= 3) {
    const catTally = new Map<string, number>();
    for (const m of mistakes) {
      catTally.set(m.category, (catTally.get(m.category) ?? 0) + 1);
    }
    const [topCat, count] = [...catTally.entries()].sort((a, b) => b[1] - a[1])[0];
    const catLabel: Record<string, string> = {
      deadline: "missed deadlines",
      test: "failed tests",
      "wasted-day": "wasted days",
      procrastination: "procrastination spirals",
      other: "unlabelled slip-ups",
    };
    if (count >= 2) {
      out.push({
        id: "mistake-cat",
        kind: "info",
        stat: `${count}`,
        headline: `Most common entry: ${catLabel[topCat] ?? topCat}`,
        body: `That's your repeat offender out of ${mistakes.length} logged entries. One recurring fix applied consistently beats a new system every week.`,
      });
    }

    // low-sleep → bad day correlation
    const lowSleepDates = new Set(
      checkins.filter((c) => (c.sleepHours ?? 7) < 6).map((c) => c.date)
    );
    const recentMistakes = mistakes.slice(0, 8);
    const linked = recentMistakes.filter((m) => lowSleepDates.has(m.date)).length;
    if (recentMistakes.length >= 4 && linked >= 2) {
      out.push({
        id: "sleep-mistakes",
        kind: "warn",
        stat: `${linked}/${recentMistakes.length}`,
        headline: "Bad days follow short nights",
        body: `${linked} of your last ${recentMistakes.length} logged slip-ups happened on a day after under-6h sleep. Tired-you breaks promises that rested-you made. Protect the night, protect the day.`,
      });
    }
  }

  if (out.length === 0) {
    out.push({
      id: "not-enough",
      kind: "info",
      headline: "Not enough ink yet",
      body: "Log about a week of check-ins and a few mistakes. Once there's real data, this page starts showing you the patterns you can't see from inside them.",
    });
  }
  return out.slice(0, 6);
}
