// Shared plain-data types (safe to import from client & server).

export interface ProfileData {
  id: number;
  name: string;
  age: number | null;
  gender: string;
  country: string;
  city: string;
  timezone: string;
  heightCm: number | null;
  typicalSleepHours: number | null;
  usualBedtime: string;
  usualWakeTime: string;
  educationLevel: string;
  focusAreas: string;
  existingSkills: string;
  skillGaps: string;
  healthNotes: string;
  badHabits: string;
  motivationStyle: string; // tough | gentle | balanced
  onboarded: boolean;
}

export interface CheckinData {
  id: number;
  date: string;
  sleepHours: number | null;
  sleepQuality: number | null;
  bedtime: string | null;
  mood: number | null;
  energy: number | null;
  emotionalLoad: string | null;
  illness: string | null;
  studyMinutes: number | null;
  exerciseDone: boolean | null;
  exerciseType: string | null;
  distraction: string | null;
}

export type MotivationStyle = "tough" | "gentle" | "balanced";

export interface GoalData {
  id: number;
  title: string;
  area: string;
  targetDate: string;
  status: string;
  notes: string;
}

export interface ApplicationData {
  id: number;
  company: string;
  role: string;
  kind: string;
  stage: string;
  link: string;
  skillsRequired: string;
  prepNotes: string;
  appliedAt: string;
}

export interface ResumeData {
  id: number;
  label: string;
  notes: string;
  createdAt: string;
}

export interface TransactionData {
  id: number;
  kind: string;
  amount: number;
  category: string;
  note: string;
  date: string;
}

export interface FinanceSettingsData {
  savingsGoalName: string;
  savingsGoalAmount: number;
  savedSoFar: number;
  monthlyBudget: number;
  currency: string;
}

export interface SkillData {
  id: number;
  domain: string;
  name: string;
  status: string;
  progress: number;
  notes: string;
}

export interface CourseData {
  id: number;
  title: string;
  platform: string;
  status: string;
  progress: number;
  url: string;
}

export interface CertData {
  id: number;
  name: string;
  status: string;
  targetDate: string;
  notes: string;
}

export interface CtfData {
  id: number;
  eventName: string;
  platform: string;
  challengesSolved: number;
  points: number;
  date: string;
  notes: string;
}

export interface CodingLogData {
  id: number;
  date: string;
  problemsSolved: number;
  platform: string;
}

export interface MistakeData {
  id: number;
  date: string;
  title: string;
  category: string;
  cause: string;
  fix: string;
}

export interface BookData {
  id: number;
  title: string;
  author: string;
  category: string;
  why: string;
  status: string;
  source: string;
}

export interface NoteData {
  id: number;
  kind: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface SettingsData {
  provider: string;
  hasKey: boolean;
  nudgesEnabled: boolean;
  studyNudgeTime: string;
  capNudges: boolean;
  exerciseNudgeTime: string;
  readingNudgeTime: string;
}
