import { db } from "@/db";
import { settings } from "@/db/schema";
import { decryptSecret } from "./crypto";

export type AiProvider = "openai" | "anthropic" | "gemini";
export type ProviderChoice = AiProvider | "none";

export interface AiCredentials {
  provider: AiProvider;
  apiKey: string;
  source: "database" | "env";
}

const ENV_KEYS: Record<AiProvider, string[]> = {
  openai: ["OPENAI_API_KEY"],
  anthropic: ["ANTHROPIC_API_KEY"],
  gemini: ["GEMINI_API_KEY", "GOOGLE_API_KEY", "GOOGLE_GENERATIVE_AI_API_KEY"],
};

function envKeyFor(provider: AiProvider): string | null {
  for (const name of ENV_KEYS[provider]) {
    const v = process.env[name];
    if (v && v.trim()) return v.trim();
  }
  return null;
}

/**
 * Resolve which provider + key to use. Stored (encrypted) DB key wins;
 * environment variables are a fallback. Returns null when nothing is set.
 */
export async function getAiCredentials(): Promise<AiCredentials | null> {
  try {
    const rows = await db.select().from(settings).limit(1);
    const s = rows[0];
    const choice = (s?.provider ?? "none") as ProviderChoice;
    if (choice !== "none") {
      const stored = s?.apiKeyEnc ? decryptSecret(s.apiKeyEnc) : null;
      if (stored) return { provider: choice, apiKey: stored, source: "database" };
      const env = envKeyFor(choice);
      if (env) return { provider: choice, apiKey: env, source: "env" };
    }
    // fallback: any env key, fixed priority
    for (const p of ["openai", "anthropic", "gemini"] as AiProvider[]) {
      const env = envKeyFor(p);
      if (env) return { provider: p, apiKey: env, source: "env" };
    }
    return null;
  } catch {
    return null;
  }
}

interface CompleteOpts {
  system?: string;
  prompt: string;
  maxTokens?: number;
  temperature?: number;
}

async function callProvider(
  provider: AiProvider,
  apiKey: string,
  opts: CompleteOpts
): Promise<string> {
  const maxTokens = opts.maxTokens ?? 400;
  const temperature = opts.temperature ?? 0.7;

  if (provider === "openai") {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        max_tokens: maxTokens,
        temperature,
        messages: [
          ...(opts.system ? [{ role: "system", content: opts.system }] : []),
          { role: "user", content: opts.prompt },
        ],
      }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`OpenAI error ${res.status}: ${body.slice(0, 180)}`);
    }
    const j = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    return j.choices?.[0]?.message?.content?.trim() ?? "";
  }

  if (provider === "anthropic") {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-5-haiku-20241022",
        max_tokens: maxTokens,
        temperature,
        ...(opts.system ? { system: opts.system } : {}),
        messages: [{ role: "user", content: opts.prompt }],
      }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Claude error ${res.status}: ${body.slice(0, 180)}`);
    }
    const j = (await res.json()) as { content?: { text?: string }[] };
    return (j.content ?? []).map((c) => c.text ?? "").join("").trim();
  }

  // gemini
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      ...(opts.system
        ? { systemInstruction: { parts: [{ text: opts.system }] } }
        : {}),
      contents: [{ role: "user", parts: [{ text: opts.prompt }] }],
      generationConfig: { maxOutputTokens: maxTokens, temperature },
    }),
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Gemini error ${res.status}: ${body.slice(0, 180)}`);
  }
  const j = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  return (
    j.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("").trim() ??
    ""
  );
}

export async function aiComplete(opts: CompleteOpts): Promise<string | null> {
  const creds = await getAiCredentials();
  if (!creds) return null;
  try {
    const out = await callProvider(creds.provider, creds.apiKey, opts);
    return out || null;
  } catch {
    return null;
  }
}

export async function testProviderConnection(
  provider: AiProvider,
  apiKey: string
): Promise<{ ok: boolean; detail: string }> {
  try {
    const out = await callProvider(provider, apiKey, {
      prompt: 'Reply with the single word: ok',
      maxTokens: 12,
      temperature: 0,
    });
    const label =
      provider === "openai"
        ? "OpenAI (gpt-4o-mini)"
        : provider === "anthropic"
          ? "Claude (haiku)"
          : "Gemini (2.0 flash)";
    return {
      ok: true,
      detail: `${label} answered${out ? `: "${out.slice(0, 24)}"` : ""}. Connection works.`,
    };
  } catch (e) {
    return {
      ok: false,
      detail: e instanceof Error ? e.message : "Connection failed",
    };
  }
}
