import { clamp, round1, timeToMinutes } from "./utils";
import type { CheckinData } from "./types";

export type CheckinLite = Pick<
  CheckinData,
  | "date"
  | "sleepHours"
  | "sleepQuality"
  | "bedtime"
  | "mood"
  | "energy"
  | "emotionalLoad"
  | "illness"
  | "studyMinutes"
  | "exerciseDone"
  | "distraction"
>;

export interface ProfileLite {
  typicalSleepHours?: number | null;
  usualBedtime?: string | null;
  usualWakeTime?: string | null;
  motivationStyle?: string | null;
}

export type CapacityMode = "recovery" | "normal" | "push";

export interface PeakWindow {
  label: string; // chronotype label
  window: string; // suggested hard-work window
  hint: string;
}

export interface Capacity {
  hours: number; // realistic focused hours today (quarter-hour steps)
  minutes: number;
  mode: CapacityMode;
  reasons: string[];
  peak: PeakWindow;
  consistencyStdMin: number | null; // night-to-night bedtime std dev
  checkedIn: boolean;
}

export function chronotype(p: ProfileLite): PeakWindow {
  const bedRaw = timeToMinutes(p.usualBedtime ?? "23:00") ?? 1380;
  const bed = bedRaw >= 720 ? bedRaw : bedRaw + 1440; // normalize past midnight
  const wake = timeToMinutes(p.usualWakeTime ?? "07:00") ?? 420;

  if (bed >= 1440 || wake >= 540) {
    return {
      label: "evening type",
      window: "19:00–22:30",
      hint: "Your brain comes online late. Put the hardest lab or new material after dinner, not in a 9am fog.",
    };
  }
  if (bed <= 1395 && wake <= 405) {
    return {
      label: "morning type",
      window: "08:30–11:30",
      hint: "You peak early. Front-load the hardest material before noon; leave review for the evening slump.",
    };
  }
  return {
    label: "intermediate type",
    window: "10:00–12:00 and 16:00–18:00",
    hint: "Two usable peaks — late morning and late afternoon. Hard stuff goes there, admin goes between.",
  };
}

/** Std dev (minutes) of actual bedtimes across recent nights. */
export function bedtimeStdMin(recent: CheckinLite[]): number | null {
  const times = recent
    .map((c) => c.bedtime)
    .filter((b): b is string => !!b)
    .map((b) => timeToMinutes(b))
    .filter((m): m is number => m != null)
    .map((m) => (m >= 720 ? m : m + 1440));
  if (times.length < 3) return null;
  const mean = times.reduce((a, b) => a + b, 0) / times.length;
  const variance =
    times.reduce((a, b) => a + (b - mean) * (b - mean), 0) / times.length;
  return Math.round(Math.sqrt(variance));
}

export function computeCapacity(opts: {
  profile: ProfileLite | null;
  today: CheckinLite | null;
  recent: CheckinLite[]; // newest first
}): Capacity {
  const reasons: string[] = [];
  const p = opts.profile ?? {};
  const t = opts.today;
  const checkedIn = !!t;

  const sleep = t?.sleepHours ?? p.typicalSleepHours ?? 7.5;
  const quality = t?.sleepQuality ?? 3;
  const energy = t?.energy ?? 3;
  const mood = t?.mood ?? 3;

  if (!t) reasons.push("No check-in yet — rough estimate from your usuals");

  // Base capacity from sleep duration + quality (0.5 – ~4.6h)
  let cap = clamp((sleep - 4.5) * 1.1, 0.5, 4.2) * (0.72 + quality * 0.07);
  // Modulate by energy and mood
  cap *= 0.58 + energy * 0.105; // 0.68 – 1.10
  cap *= 0.82 + mood * 0.045; // 0.87 – 1.05

  if (sleep < 6) reasons.push(`${round1(sleep)}h of sleep — that's the real ceiling today`);
  else if (sleep >= 7.5 && quality >= 4)
    reasons.push(`Well rested (${round1(sleep)}h, ${quality}/5) — the engine's warm`);

  if (quality <= 2) reasons.push("Sleep quality was poor even if the hours looked okay");
  if (energy <= 2) reasons.push("Low energy logged — focus will cost double today");
  else if (energy >= 4) reasons.push("High energy — spend it before it evaporates");
  if (mood <= 2) reasons.push("Mood's down — count small wins, don't chase a big number");

  // Sleep consistency matters, not just duration
  const std = bedtimeStdMin(opts.recent);
  if (std != null && std > 80) {
    cap *= 0.88;
    reasons.push(
      `Bedtime's swinging ~${std} min night to night — irregular sleep quietly cuts capacity even when hours look fine`
    );
  } else if (std != null && std <= 45) {
    reasons.push("Bedtime's been steady — that pays off more than one heroic long night");
  }

  let mode: CapacityMode = "normal";
  const heavy = (t?.emotionalLoad ?? "").trim().length > 0;
  const sick = (t?.illness ?? "").trim().length > 0;

  if (heavy) {
    cap = Math.min(cap, 1.75);
    mode = "recovery";
    reasons.push("Heavy day logged — target lowered on purpose. Review, flashcards, no new hard material.");
  }
  if (sick) {
    cap = Math.min(cap, 1.5);
    mode = "recovery";
    reasons.push("You're not well — rest is the productive move today.");
  }

  // Push mode: three solid days behind + rested today
  if (mode === "normal" && t) {
    const recent3 = opts.recent.filter((c) => c.date !== t.date).slice(0, 3);
    const solidDays = recent3.filter((c) => (c.studyMinutes ?? 0) >= 70).length;
    if (solidDays >= 3 && energy >= 4 && sleep >= 6.5) {
      cap += 0.5;
      mode = "push";
      reasons.push("Three solid days behind you — you can stretch a little today");
    }
  }

  cap = clamp(cap, 0.5, 6.5);
  const hours = Math.round(cap * 4) / 4;

  return {
    hours,
    minutes: Math.round(hours * 60),
    mode,
    reasons,
    peak: chronotype(p),
    consistencyStdMin: std,
    checkedIn,
  };
}

export function capacityTemplateMessage(
  c: Capacity,
  style: string,
  sleepHours: number | null
): string {
  const h = c.hours;
  if (c.mode === "recovery") {
    return style === "tough"
      ? `Today hurt, so the target is small on purpose: ${h}h of light review. Do that and you still moved. Skip it and tomorrow's heavier.`
      : `Days like this count too. ${h}h of light review — flashcards, old notes — is genuinely enough. Be on your own side today.`;
  }
  if (c.mode === "push") {
    return `You're rested and the streak is alive. ${h} focused hours is the honest number — hardest work goes in your peak window (${c.peak.window}). No negotiations.`;
  }
  const sleepBit =
    sleepHours != null && sleepHours < 6
      ? ` You're running on ${round1(sleepHours)}h of sleep — pretending otherwise just builds a debt you pay tomorrow.`
      : "";
  if (style === "tough") {
    return `Realistic today: ${h} focused hours. Not 6.${sleepBit} Hit it, log it, done.`;
  }
  if (style === "gentle") {
    return `Realistic today: ${h} focused hours — a number you can actually hit.${sleepBit} Start small in your peak window (${c.peak.window}) and let momentum do the rest.`;
  }
  return `Realistic today: ${h} focused hours. Your inputs say so — not your guilt.${sleepBit} Hardest work goes in ${c.peak.window}.`;
}

export const COACH_SYSTEM = `You are FixMe — the user's blunt, honest personal coach for study, cybersecurity skill-building, and life. You speak like a close friend who tells the truth, never like corporate software. Rules:
- Match the requested tone exactly: "tough" = direct, challenging, zero coddling but never cruel; "gentle" = warm, validating, tiny steps; "balanced" = honest but kind.
- Second person, plain words, short sentences. 2-4 sentences max unless told otherwise.
- Never mention being an AI, a model, or a language model. No emojis, no hashtags, no bullet-point hype.
- This is a cybersecurity CS student. Reference real things (labs, CTFs, certs, boxes) when relevant, stay concrete.
- If the user logged something emotionally heavy, lead with care before any push.`;
