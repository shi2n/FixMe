"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, Sparkles, KeyRound, BookOpen, Check } from "lucide-react";
import Link from "next/link";
import {
  getBooks,
  addBook,
  updateBook,
  deleteBook,
} from "@/app/actions/logs";
import { getBookSuggestions, type BookSuggestion } from "@/app/actions/ai";
import { cn } from "@/lib/utils";
import type { BookData } from "@/lib/types";

const STATUS_FLOW = ["to-read", "reading", "done"];

function nextStatus(s: string): string {
  const i = STATUS_FLOW.indexOf(s);
  return STATUS_FLOW[(i + 1) % STATUS_FLOW.length];
}

const CAT_LABEL: Record<string, string> = {
  cyber: "cybersecurity",
  cs: "cs craft",
  personal: "the human stuff",
};

export default function ReadingPage() {
  const [books, setBooks] = useState<BookData[] | null>(null);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [category, setCategory] = useState("cyber");

  const [aiBusy, setAiBusy] = useState(false);
  const [needsKey, setNeedsKey] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<BookSuggestion[]>([]);
  const [addedIdx, setAddedIdx] = useState<number[]>([]);

  useEffect(() => {
    getBooks().then(setBooks).catch(() => setBooks([]));
  }, []);

  const suggest = async () => {
    setAiBusy(true);
    setNeedsKey(false);
    setAiError(null);
    setAddedIdx([]);
    try {
      const res = await getBookSuggestions();
      if (res.needsKey) setNeedsKey(true);
      else if (res.error) setAiError(res.error);
      setSuggestions(res.suggestions);
    } finally {
      setAiBusy(false);
    }
  };

  if (!books) return <p className="py-16 text-sm text-faint">opening the shelf…</p>;

  const groups: { status: string; label: string; items: BookData[] }[] = [
    { status: "reading", label: "currently reading", items: books.filter((b) => b.status === "reading") },
    { status: "to-read", label: "on the list", items: books.filter((b) => b.status === "to-read") },
    { status: "done", label: "finished", items: books.filter((b) => b.status === "done") },
  ];

  return (
    <div className="py-10">
      <h1 className="font-hand text-5xl font-bold text-ink">reading list</h1>
      <p className="mt-1 text-sm text-muted">
        real books, chosen for what you&apos;re actually building and going
        through. ten pages a night beats a heroic weekend.
      </p>

      {/* add + AI row */}
      <div className="card mt-6 p-5">
        <form
          className="flex flex-wrap gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!title.trim()) return;
            setBooks(await addBook({ title, author, category, source: "manual" }));
            setTitle("");
            setAuthor("");
          }}
        >
          <input className="field flex-1" placeholder="title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="field w-52" placeholder="author" value={author} onChange={(e) => setAuthor(e.target.value)} />
          <select className="field w-44" value={category} onChange={(e) => setCategory(e.target.value)}>
            {Object.entries(CAT_LABEL).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
          <button className="btn-hl" type="submit">
            <Plus size={15} /> add
          </button>
        </form>

        <div className="mt-4 border-t border-line pt-4">
          <div className="flex flex-wrap items-center gap-3">
            <button className="btn-ghost" onClick={suggest} disabled={aiBusy}>
              <Sparkles size={15} className="text-hl" />
              {aiBusy ? "asking your AI…" : "recommend 4 real books for me"}
            </button>
            <p className="text-[11px] text-faint">
              uses your profile, skill gaps and the last two weeks of mood — not a
              generic top-10 list.
            </p>
          </div>

          {needsKey && (
            <div className="paper-note tilt-l mt-4 max-w-md p-5">
              <p className="flex items-center gap-1.5 text-[11px] font-bold text-[#6f6435]">
                <KeyRound size={12} /> no AI key connected
              </p>
              <p className="mt-1.5 font-hand text-[21px] leading-snug">
                the recommender runs on your own OpenAI / Claude / Gemini key.
                add it in Settings and come back.
              </p>
              <Link href="/settings" className="mt-3 inline-block rounded-lg bg-[#3a3317] px-3.5 py-2 text-xs font-bold text-[#ece0af] transition-transform hover:-translate-y-0.5">
                open settings
              </Link>
            </div>
          )}

          {aiError && <p className="mt-3 text-[13px] text-faint">{aiError}</p>}

          {suggestions.length > 0 && (
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {suggestions.map((s, i) => (
                <div key={`${s.title}-${i}`} className="rounded-xl border border-hl/30 bg-bg-deep p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-[15px] font-semibold text-ink">{s.title}</p>
                      <p className="text-[12px] text-muted">{s.author}</p>
                    </div>
                    <span className="chip shrink-0 !text-[10px]">{CAT_LABEL[s.category]}</span>
                  </div>
                  <p className="mt-2 text-[13px] leading-snug text-muted">{s.why}</p>
                  <button
                    disabled={addedIdx.includes(i)}
                    onClick={async () => {
                      setBooks(await addBook({ title: s.title, author: s.author, category: s.category, why: s.why, source: "ai" }));
                      setAddedIdx((v) => [...v, i]);
                    }}
                    className={cn("btn-ghost mt-3 !py-1.5 text-xs", addedIdx.includes(i) && "!text-hl")}
                  >
                    {addedIdx.includes(i) ? (<><Check size={13} /> on the list</>) : (<><Plus size={13} /> add to my list</>)}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* shelf */}
      {groups.map((g) => (
        <div key={g.status} className="mt-8">
          <h2 className="font-hand text-3xl font-semibold text-ink">
            {g.label} <span className="text-faint">({g.items.length})</span>
          </h2>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            {g.items.map((b) => (
              <div key={b.id} className={cn("card card-hover group p-4", b.status === "done" && "opacity-60")}>
                <div className="flex items-start gap-3">
                  <button
                    onClick={async () => setBooks(await updateBook(b.id, { status: nextStatus(b.status) }))}
                    title={`status: ${b.status} — click to advance`}
                    className={cn(
                      "mt-0.5 shrink-0 rounded-lg border p-2 transition-all hover:scale-110",
                      b.status === "done" ? "border-hl bg-hl text-[#1c1c1b]" : b.status === "reading" ? "border-hl/60 text-hl" : "border-line text-faint"
                    )}
                  >
                    {b.status === "done" ? <Check size={15} /> : <BookOpen size={15} />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className={cn("text-[15px] font-semibold text-ink", b.status === "done" && "line-through decoration-hl/60")}>
                      {b.title}
                    </p>
                    <p className="text-[12px] text-muted">{b.author}</p>
                    {b.why && (
                      <p className="mt-1.5 text-[12px] leading-snug text-faint">{b.why}</p>
                    )}
                    <div className="mt-2 flex gap-1.5">
                      <span className="chip !py-0.5 !text-[10px]">{CAT_LABEL[b.category] ?? b.category}</span>
                      {b.source === "ai" && (
                        <span className="chip !py-0.5 !text-[10px] !text-hl">
                          <Sparkles size={9} /> ai pick
                        </span>
                      )}
                      {b.source === "curated" && (
                        <span className="chip !py-0.5 !text-[10px]">starter shelf</span>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={async () => setBooks(await deleteBook(b.id))}
                    className="shrink-0 rounded p-1.5 text-faint opacity-0 transition-opacity group-hover:opacity-100 hover:text-hl"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
