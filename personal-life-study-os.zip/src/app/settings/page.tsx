"use client";

import { useEffect, useState } from "react";
import {
  Check,
  KeyRound,
  ShieldCheck,
  BellRing,
  FlaskConical,
  Trash2,
  Save,
  Smartphone,
} from "lucide-react";
import { getProfile, saveProfile } from "@/app/actions/data";
import {
  getSettings,
  saveProvider,
  saveApiKey,
  clearApiKey,
  testConnection,
  saveNudges,
} from "@/app/actions/settings";
import { cn } from "@/lib/utils";
import type { ProfileData, SettingsData } from "@/lib/types";

const QUIZ: { q: string; a: string; b: string }[] = [
  {
    q: "You skipped studying all day. What actually gets you moving tomorrow?",
    a: "Someone telling me I burned a day I can't get back.",
    b: "Someone reminding me one bad day erases nothing — start tiny.",
  },
  {
    q: "Two hours into a brutal lab, fully stuck. You want to hear:",
    a: "\"Stop staring, break it into pieces, keep going.\"",
    b: "\"Stuck is the normal middle of learning. Take five, one small step.\"",
  },
  {
    q: "You just hit a 14-day streak. The better message is:",
    a: "\"Good. Now protect it like it belongs to you.\"",
    b: "\"Look how far you've come. Quietly proud of you.\"",
  },
];

const PROVIDERS = [
  { id: "none", label: "Off — rules only" },
  { id: "openai", label: "OpenAI (ChatGPT)" },
  { id: "anthropic", label: "Anthropic (Claude)" },
  { id: "gemini", label: "Google (Gemini)" },
];

export default function SettingsPage() {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [settings, setSettings] = useState<SettingsData | null>(null);
  const [savedProfile, setSavedProfile] = useState(false);

  const [answers, setAnswers] = useState<(0 | 1 | null)[]>([null, null, null]);

  const [apiKey, setApiKey] = useState("");
  const [keySaved, setKeySaved] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; detail: string } | null>(null);
  const [testing, setTesting] = useState(false);

  const [notifHint, setNotifHint] = useState("");

  useEffect(() => {
    getProfile().then(setProfile).catch(() => {});
    getSettings().then(setSettings).catch(() => {});
  }, []);

  const saveP = async () => {
    if (!profile) return;
    const { id: _id, ...patch } = profile;
    void _id;
    setProfile(await saveProfile(patch));
    setSavedProfile(true);
    setTimeout(() => setSavedProfile(false), 1600);
  };

  const quizResult = (() => {
    if (answers.some((a) => a === null)) return null;
    const tough = answers.filter((a) => a === 0).length;
    if (tough >= 2) return "tough";
    if (tough === 0) return "gentle";
    return "balanced";
  })();

  useEffect(() => {
    if (!quizResult || !profile) return;
    if (profile.motivationStyle !== quizResult) {
      saveProfile({ motivationStyle: quizResult }).then(setProfile).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quizResult]);

  if (!profile || !settings) {
    return <p className="py-16 text-sm text-faint">opening the drawer…</p>;
  }

  const set = (patch: Partial<ProfileData>) => setProfile({ ...profile, ...patch });

  return (
    <div className="py-10">
      <h1 className="font-hand text-5xl font-bold text-ink">settings</h1>
      <p className="mt-1 text-sm text-muted">
        everything here is editable anytime, and none of it leaves this server.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        {/* ---------------- profile ---------------- */}
        <div className="card p-6">
          <h2 className="font-hand text-[28px] font-semibold text-ink">the basics</h2>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div>
              <label className="label">name</label>
              <input className="field" value={profile.name} onChange={(e) => set({ name: e.target.value })} placeholder="what the coach calls you" />
            </div>
            <div>
              <label className="label">age</label>
              <input type="number" className="field" value={profile.age ?? ""} onChange={(e) => set({ age: Number(e.target.value) || null })} />
            </div>
            <div>
              <label className="label">gender</label>
              <input className="field" value={profile.gender} onChange={(e) => set({ gender: e.target.value })} />
            </div>
            <div>
              <label className="label">height (cm)</label>
              <input type="number" className="field" value={profile.heightCm ?? ""} onChange={(e) => set({ heightCm: Number(e.target.value) || null })} />
            </div>
            <div>
              <label className="label">country</label>
              <input className="field" value={profile.country} onChange={(e) => set({ country: e.target.value })} />
            </div>
            <div>
              <label className="label">city</label>
              <input className="field" value={profile.city} onChange={(e) => set({ city: e.target.value })} />
            </div>
            <div className="col-span-2">
              <label className="label">timezone</label>
              <input className="field" value={profile.timezone} onChange={(e) => set({ timezone: e.target.value })} placeholder="e.g. Asia/Karachi" />
            </div>

            <div>
              <label className="label">usual bedtime</label>
              <input type="time" className="field" value={profile.usualBedtime} onChange={(e) => set({ usualBedtime: e.target.value })} />
            </div>
            <div>
              <label className="label">usual wake time</label>
              <input type="time" className="field" value={profile.usualWakeTime} onChange={(e) => set({ usualWakeTime: e.target.value })} />
            </div>
            <div className="col-span-2">
              <label className="label">typical sleep (hours) — bedtime/wake set your chronotype &amp; peak window</label>
              <input type="number" step="0.5" min={3} max={12} className="field" value={profile.typicalSleepHours ?? 7.5} onChange={(e) => set({ typicalSleepHours: Number(e.target.value) || 7.5 })} />
            </div>

            <div>
              <label className="label">education — year/level</label>
              <input className="field" value={profile.educationLevel} onChange={(e) => set({ educationLevel: e.target.value })} placeholder="BS CS, 2nd year" />
            </div>
            <div>
              <label className="label">current focus areas</label>
              <input className="field" value={profile.focusAreas} onChange={(e) => set({ focusAreas: e.target.value })} placeholder="web security, networking" />
            </div>
            <div className="col-span-2">
              <label className="label">existing skills (comma list)</label>
              <input className="field" value={profile.existingSkills} onChange={(e) => set({ existingSkills: e.target.value })} placeholder="python, linux basics, html" />
            </div>
            <div className="col-span-2">
              <label className="label">known skill gaps</label>
              <input className="field" value={profile.skillGaps} onChange={(e) => set({ skillGaps: e.target.value })} placeholder="crypto math, assembly, windows internals" />
            </div>
            <div className="col-span-2">
              <label className="label">health notes — private, optional</label>
              <textarea rows={2} className="field resize-none" value={profile.healthNotes} onChange={(e) => set({ healthNotes: e.target.value })} placeholder="anything the capacity engine should respect" />
            </div>
            <div className="col-span-2">
              <label className="label">bad habits being tracked</label>
              <input className="field" value={profile.badHabits} onChange={(e) => set({ badHabits: e.target.value })} placeholder="phone scrolling, 3am bedtimes, skipping the gym" />
            </div>
          </div>
          <button onClick={saveP} className={cn("btn-hl mt-5", savedProfile && "!bg-ink !text-bg")}>
            {savedProfile ? (<><Check size={15} /> saved</>) : (<><Save size={15} /> save profile</>)}
          </button>
        </div>

        {/* ---------------- quiz ---------------- */}
        <div className="card p-6">
          <h2 className="font-hand text-[28px] font-semibold text-ink">
            how should the coach talk to you?
          </h2>
          <p className="mt-1 text-[13px] text-muted">
            don&apos;t answer what sounds noble — answer what would actually move
            you at 11pm on a dead day.
          </p>
          <div className="mt-5 space-y-5">
            {QUIZ.map((item, i) => (
              <div key={i}>
                <p className="text-[14px] font-medium text-ink">{i + 1}. {item.q}</p>
                <div className="mt-2 grid gap-2">
                  {[item.a, item.b].map((opt, j) => (
                    <button
                      key={j}
                      onClick={() => setAnswers((prev) => prev.map((v, k) => (k === i ? (j as 0 | 1) : v)))}
                      className={cn(
                        "rounded-lg border px-3.5 py-2.5 text-left text-[13px] transition-all duration-200",
                        answers[i] === j
                          ? "border-hl bg-hl/10 text-ink shadow-[inset_3px_0_0_#f5d500]"
                          : "border-line text-muted hover:border-hl/40 hover:text-ink"
                      )}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-line pt-4">
            <span className="text-xs text-faint">your style:</span>
            {(["tough", "gentle", "balanced"] as const).map((s) => (
              <button
                key={s}
                onClick={async () => setProfile(await saveProfile({ motivationStyle: s }))}
                className={cn(
                  "rounded-full border px-3.5 py-1.5 text-xs font-bold transition-all",
                  profile.motivationStyle === s
                    ? "border-hl bg-hl text-[#1c1c1b]"
                    : "border-line text-muted hover:text-ink"
                )}
              >
                {s === "tough" ? "tough love" : s}
              </button>
            ))}
            {quizResult && (
              <span className="text-[11px] text-hl">← quiz says {quizResult}</span>
            )}
          </div>
        </div>

        {/* ---------------- AI engine ---------------- */}
        <div className="card p-6">
          <h2 className="flex items-center gap-2 font-hand text-[28px] font-semibold text-ink">
            <KeyRound size={20} className="text-hl" /> the AI engine
          </h2>
          <p className="mt-1 text-[13px] leading-relaxed text-muted">
            one pipe powers everything: the daily capacity read, reminder
            messages, pattern insights, book picks and ask-your-data. pick a
            provider, paste your own key, and usage bills go to your account —
            this site charges nothing.
          </p>

          <div className="mt-4">
            <label className="label">provider</label>
            <div className="grid grid-cols-2 gap-2">
              {PROVIDERS.map((p) => (
                <button
                  key={p.id}
                  onClick={async () => setSettings(await saveProvider(p.id as SettingsData["provider"] as never))}
                  className={cn(
                    "rounded-lg border px-3 py-2.5 text-left text-[13px] font-medium transition-all",
                    settings.provider === p.id
                      ? "border-hl bg-hl/10 text-ink shadow-[inset_3px_0_0_#f5d500]"
                      : "border-line text-muted hover:text-ink"
                  )}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <label className="label">
              api key {settings.hasKey && <span className="text-hl">— one is stored</span>}
            </label>
            <div className="flex gap-2">
              <input
                type="password"
                className="field"
                placeholder={settings.hasKey ? "stored — paste a new one to replace" : "sk-... / sk-ant-... / AIza..."}
                value={apiKey}
                onChange={(e) => {
                  setApiKey(e.target.value);
                  setKeySaved(false);
                }}
                autoComplete="off"
              />
              <button
                className={cn("btn-hl shrink-0", keySaved && "!bg-ink !text-bg")}
                onClick={async () => {
                  if (!apiKey.trim()) return;
                  setSettings(await saveApiKey(apiKey));
                  setApiKey("");
                  setKeySaved(true);
                  setTimeout(() => setKeySaved(false), 2000);
                }}
              >
                {keySaved ? <Check size={15} /> : "save key"}
              </button>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2.5">
            <button
              className="btn-ghost"
              disabled={testing}
              onClick={async () => {
                setTesting(true);
                setTestResult(null);
                try {
                  setTestResult(await testConnection());
                } finally {
                  setTesting(false);
                }
              }}
            >
              <FlaskConical size={15} className="text-hl" />
              {testing ? "pinging…" : "test connection"}
            </button>
            <button
              className="btn-ghost !text-faint hover:!text-hl"
              onClick={async () => {
                setSettings(await clearApiKey());
                setTestResult(null);
              }}
            >
              <Trash2 size={14} /> remove stored key
            </button>
          </div>

          {testResult && (
            <p className={cn("mt-3 rounded-lg border p-3 text-[13px]", testResult.ok ? "border-hl/40 text-ink" : "border-line text-faint")}>
              {testResult.ok ? "✓ " : "✗ "}
              {testResult.detail}
            </p>
          )}

          <div className="mt-5 flex gap-2.5 rounded-xl border border-line bg-bg-deep p-3.5">
            <ShieldCheck size={16} className="mt-0.5 shrink-0 text-hl" />
            <p className="text-[12px] leading-relaxed text-muted">
              the key is AES-256 encrypted before it touches the database and is
              only ever decrypted by server-side functions at request time. it is
              never sent to your browser, never logged, and no action returns it
              — the settings payload only carries &quot;a key exists&quot;.
              env vars (OPENAI_API_KEY etc.) work too, as a fallback.
            </p>
          </div>
        </div>

        {/* ---------------- nudges ---------------- */}
        <div className="card p-6">
          <h2 className="flex items-center gap-2 font-hand text-[28px] font-semibold text-ink">
            <BellRing size={20} className="text-hl" /> nudges
          </h2>
          <p className="mt-1 text-[13px] leading-relaxed text-muted">
            messages are written in the moment using today&apos;s mood, energy
            and your coach style — on heavy days the tone softens on its own.
          </p>

          <div className="mt-5 space-y-4">
            <label className="flex items-center justify-between gap-4">
              <span className="text-sm text-ink">nudges on</span>
              <button
                onClick={async () => {
                  const next = !settings.nudgesEnabled;
                  if (next && "Notification" in window && Notification.permission === "default") {
                    const p = await Notification.requestPermission();
                    if (p !== "granted") {
                      setNotifHint("notifications are blocked in the browser — nudges will wait until you allow them.");
                    } else {
                      setNotifHint("");
                    }
                  }
                  setSettings(await saveNudges({ nudgesEnabled: next }));
                }}
                className={cn(
                  "h-7 w-12 rounded-full p-1 transition-colors",
                  settings.nudgesEnabled ? "bg-hl" : "bg-card2"
                )}
              >
                <span
                  className={cn(
                    "block h-5 w-5 rounded-full bg-bg transition-transform",
                    settings.nudgesEnabled && "translate-x-5"
                  )}
                />
              </button>
            </label>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">study nudge — if nothing logged by</label>
                <input
                  type="time"
                  className="field"
                  value={settings.studyNudgeTime}
                  onChange={async (e) => setSettings(await saveNudges({ studyNudgeTime: e.target.value }))}
                />
              </div>
              <div>
                <label className="label">exercise reminder</label>
                <input
                  type="time"
                  className="field"
                  value={settings.exerciseNudgeTime}
                  onChange={async (e) => setSettings(await saveNudges({ exerciseNudgeTime: e.target.value }))}
                />
              </div>
              <div>
                <label className="label">reading nudge</label>
                <input
                  type="time"
                  className="field"
                  value={settings.readingNudgeTime}
                  onChange={async (e) => setSettings(await saveNudges({ readingNudgeTime: e.target.value }))}
                />
              </div>
              <label className="flex items-end justify-between gap-2 pb-1">
                <span className="text-[13px] text-ink">&quot;stop — you hit the cap&quot; nudges</span>
                <button
                  onClick={async () => setSettings(await saveNudges({ capNudges: !settings.capNudges }))}
                  className={cn("h-7 w-12 shrink-0 rounded-full p-1 transition-colors", settings.capNudges ? "bg-hl" : "bg-card2")}
                >
                  <span className={cn("block h-5 w-5 rounded-full bg-bg transition-transform", settings.capNudges && "translate-x-5")} />
                </button>
              </label>
            </div>

            {notifHint && <p className="text-[12px] text-faint">{notifHint}</p>}

            <div className="flex gap-2.5 rounded-xl border border-line bg-bg-deep p-3.5">
              <Smartphone size={16} className="mt-0.5 shrink-0 text-hl" />
              <p className="text-[12px] leading-relaxed text-muted">
                nudges fire while FixMe is open (or installed and running) — on
                iPhone use Share → Add to Home Screen so it behaves like a real
                app. burnout-nudges matter as much as study-nudges: rest is
                scheduled work.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
