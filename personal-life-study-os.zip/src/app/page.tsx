import Hero from "@/components/Hero";
import TodayClient from "@/components/TodayClient";
import PomodoroClient from "@/components/PomodoroClient";
import InsightsClient from "@/components/InsightsClient";
import AskDataClient from "@/components/AskDataClient";
import MethodsGuide from "@/components/MethodsGuide";
import NotesClient from "@/components/NotesClient";

export default function Home() {
  return (
    <>
      <Hero />
      <TodayClient />
      <PomodoroClient />
      <InsightsClient />
      <AskDataClient />
      <MethodsGuide />
      <NotesClient />

      <p className="mx-auto mt-24 max-w-md -rotate-[0.7deg] text-center font-hand text-[26px] leading-snug text-muted">
        you don&apos;t rise to the level of your goals —{" "}
        <span className="marker-underline text-ink">
          you fall to the level of your sleep schedule.
        </span>
      </p>
      <div className="pb-4" />
    </>
  );
}
