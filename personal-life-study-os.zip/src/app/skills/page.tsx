"use client";

import { useEffect, useMemo, useState } from "react";
import { Plus, Trash2, Sprout, Swords, Terminal, Award, ShieldHalf } from "lucide-react";
import {
  getSkillsData,
  upsertSkill,
  deleteSkill,
  upsertCourse,
  deleteCourse,
  upsertCert,
  deleteCert,
  addCtf,
  deleteCtf,
  logCoding,
  deleteCodingLog,
  seedSkillTemplate,
  type SkillsData,
} from "@/app/actions/skills";
import { cn, fmtDate, daysAgoStr } from "@/lib/utils";

const SKILL_STATUSES = ["planned", "learning", "practicing", "solid"];
const CERT_STATUSES = ["planned", "studying", "scheduled", "earned"];
const DOMAIN_ORDER = [
  "networking",
  "web security",
  "linux",
  "crypto",
  "reversing & pwn",
  "blue team",
  "coding",
  "general",
];

function statusChipClass(s: string): string {
  if (s === "solid" || s === "earned")
    return "bg-hl text-[#1c1c1b] border-hl font-bold";
  if (s === "practicing" || s === "studying")
    return "border-hl/60 text-hl";
  if (s === "scheduled") return "border-ink/50 text-ink";
  return "border-line text-faint";
}

export default function SkillsPage() {
  const [data, setData] = useState<SkillsData | null>(null);

  const [newSkillName, setNewSkillName] = useState<Record<string, string>>({});
  const [newDomain, setNewDomain] = useState("");
  const [newDomainSkill, setNewDomainSkill] = useState("");

  const [courseTitle, setCourseTitle] = useState("");
  const [coursePlatform, setCoursePlatform] = useState("");

  const [certName, setCertName] = useState("");
  const [certDate, setCertDate] = useState("");

  const [ctfName, setCtfName] = useState("");
  const [ctfPlatform, setCtfPlatform] = useState("");
  const [ctfSolved, setCtfSolved] = useState("");
  const [ctfPoints, setCtfPoints] = useState("");

  const [codeCount, setCodeCount] = useState("");
  const [codePlatform, setCodePlatform] = useState("leetcode");

  useEffect(() => {
    getSkillsData().then(setData).catch(() => setData({ skills: [], courses: [], certs: [], ctfs: [], coding: [] }));
  }, []);

  const stats = useMemo(() => {
    if (!data) return { challenges: 0, points: 0, weekProblems: 0, solid: 0 };
    const weekAgo = daysAgoStr(6);
    return {
      challenges: data.ctfs.reduce((a, c) => a + c.challengesSolved, 0),
      points: data.ctfs.reduce((a, c) => a + c.points, 0),
      weekProblems: data.coding
        .filter((c) => c.date >= weekAgo)
        .reduce((a, c) => a + c.problemsSolved, 0),
      solid: data.skills.filter((s) => s.status === "solid").length,
    };
  }, [data]);

  if (!data) return <p className="py-16 text-sm text-faint">sharpening…</p>;

  const domains = new Map<string, SkillsData["skills"]>();
  for (const s of data.skills) {
    if (!domains.has(s.domain)) domains.set(s.domain, []);
    domains.get(s.domain)!.push(s);
  }
  const orderedDomains = [...domains.keys()].sort(
    (a, b) =>
      (DOMAIN_ORDER.indexOf(a) === -1 ? 99 : DOMAIN_ORDER.indexOf(a)) -
      (DOMAIN_ORDER.indexOf(b) === -1 ? 99 : DOMAIN_ORDER.indexOf(b))
  );

  const certOrder = [...data.certs];

  return (
    <div className="py-10">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-3 font-hand text-5xl font-bold text-ink">
            the skill tree <ShieldHalf className="text-hl" size={30} />
          </h1>
          <p className="mt-1 text-sm text-muted">
            networking → web → linux → pwn. branches fill as you do the work —
            not as you watch videos about the work.
          </p>
        </div>
      </div>

      {data.skills.length === 0 && (
        <div className="mt-8 card p-8 text-center">
          <Sprout size={28} className="mx-auto text-hl" />
          <p className="mx-auto mt-3 max-w-md text-sm text-muted">
            the tree is empty. plant the cybersecurity starter set — networking,
            web security, linux, crypto, pwn, blue team, coding — then bend it
            into your own shape.
          </p>
          <button
            className="btn-hl mx-auto mt-5"
            onClick={async () => setData(await seedSkillTemplate())}
          >
            <Sprout size={15} /> plant the cybersecurity tree
          </button>
        </div>
      )}

      {/* numbers that matter */}
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
        {[
          { k: "ctf challenges solved", v: String(stats.challenges), icon: Swords },
          { k: "ctf points", v: String(stats.points), icon: Award },
          { k: "coding problems (7d)", v: String(stats.weekProblems), icon: Terminal },
          { k: "skills marked solid", v: String(stats.solid), icon: ShieldHalf },
        ].map((s) => (
          <div key={s.k} className="card card-hover p-4">
            <s.icon size={16} className="text-hl" />
            <p className="mt-2 text-3xl font-bold tracking-tight text-ink">{s.v}</p>
            <p className="mt-0.5 text-[11px] text-faint">{s.k}</p>
          </div>
        ))}
      </div>

      {/* skill tree by domain */}
      {orderedDomains.length > 0 && (
        <div className="mt-10">
          <h2 className="font-hand text-3xl font-semibold text-ink">branches</h2>
          <div className="mt-4 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {orderedDomains.map((domain, di) => {
              const list = domains.get(domain)!;
              const avg = Math.round(list.reduce((a, s) => a + s.progress, 0) / list.length);
              return (
                <div
                  key={domain}
                  className={cn("card card-hover p-5", di === 2 && "md:-rotate-[0.5deg]")}
                >
                  <div className="flex items-baseline justify-between">
                    <h3 className="font-hand text-[24px] font-semibold text-ink">{domain}</h3>
                    <span className="text-xs font-bold text-hl">{avg}%</span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-bg-deep">
                    <div className="h-full rounded-full bg-hl/85 transition-all duration-500" style={{ width: `${avg}%` }} />
                  </div>
                  <div className="mt-4 space-y-3">
                    {list.map((s) => (
                      <div key={s.id}>
                        <div className="flex items-center gap-2">
                          <select
                            value={s.status}
                            onChange={async (e) =>
                              setData(await upsertSkill({ id: s.id, name: s.name, domain: s.domain, status: e.target.value, progress: s.progress, notes: s.notes }))
                            }
                            className={cn("cursor-pointer rounded-full border bg-transparent px-2 py-0.5 text-[10px] font-semibold outline-none", statusChipClass(s.status))}
                          >
                            {SKILL_STATUSES.map((st) => (
                              <option key={st} className="bg-card text-ink">{st}</option>
                            ))}
                          </select>
                          <span className="min-w-0 flex-1 truncate text-[13px] text-ink">{s.name}</span>
                          <button
                            onClick={async () => setData(await deleteSkill(s.id))}
                            className="shrink-0 rounded p-1 text-faint hover:text-hl"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                        <div className="mt-1 flex items-center gap-2 pl-1">
                          <input
                            type="range"
                            min={0}
                            max={100}
                            step={5}
                            value={s.progress}
                            onChange={async (e) =>
                              setData(await upsertSkill({ id: s.id, name: s.name, domain: s.domain, status: s.status, progress: Number(e.target.value), notes: s.notes }))
                            }
                            className="h-1 flex-1 cursor-pointer accent-hl"
                          />
                          <span className="w-8 text-right text-[10px] text-faint tabular-nums">{s.progress}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <form
                    className="mt-4 flex gap-1.5"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const name = (newSkillName[domain] ?? "").trim();
                      if (!name) return;
                      setData(await upsertSkill({ name, domain }));
                      setNewSkillName({ ...newSkillName, [domain]: "" });
                    }}
                  >
                    <input
                      className="field !py-1.5 text-xs"
                      placeholder={`add a ${domain} leaf`}
                      value={newSkillName[domain] ?? ""}
                      onChange={(e) => setNewSkillName({ ...newSkillName, [domain]: e.target.value })}
                    />
                    <button className="btn-ghost !px-2.5 !py-1.5" type="submit">
                      <Plus size={13} />
                    </button>
                  </form>
                </div>
              );
            })}
          </div>

          {/* new domain */}
          <form
            className="mt-5 flex max-w-md gap-2"
            onSubmit={async (e) => {
              e.preventDefault();
              if (!newDomain.trim() || !newDomainSkill.trim()) return;
              setData(await upsertSkill({ name: newDomainSkill, domain: newDomain.toLowerCase() }));
              setNewDomain("");
              setNewDomainSkill("");
            }}
          >
            <input className="field" placeholder="new branch (e.g. cloud, osint)" value={newDomain} onChange={(e) => setNewDomain(e.target.value)} />
            <input className="field" placeholder="first leaf on it" value={newDomainSkill} onChange={(e) => setNewDomainSkill(e.target.value)} />
            <button className="btn-hl !px-3" type="submit">
              <Plus size={15} />
            </button>
          </form>
        </div>
      )}

      <div className="mt-12 grid gap-6 lg:grid-cols-2">
        {/* courses */}
        <div className="card p-5">
          <h2 className="font-hand text-[26px] font-semibold text-ink">courses in progress</h2>
          <form
            className="mt-3 flex gap-2"
            onSubmit={async (e) => {
              e.preventDefault();
              if (!courseTitle.trim()) return;
              setData(await upsertCourse({ title: courseTitle, platform: coursePlatform }));
              setCourseTitle("");
              setCoursePlatform("");
            }}
          >
            <input className="field" placeholder="course — e.g. PortSwigger Web Security Academy" value={courseTitle} onChange={(e) => setCourseTitle(e.target.value)} />
            <input className="field w-36" placeholder="platform" value={coursePlatform} onChange={(e) => setCoursePlatform(e.target.value)} />
            <button className="btn-hl !px-3" type="submit"><Plus size={15} /></button>
          </form>
          <div className="mt-4 space-y-3">
            {data.courses.map((c) => (
              <div key={c.id} className="rounded-lg border border-line bg-bg-deep p-3.5">
                <div className="flex items-center gap-2">
                  <select
                    value={c.status}
                    onChange={async (e) => setData(await upsertCourse({ id: c.id, title: c.title, platform: c.platform, status: e.target.value, progress: c.progress, url: c.url }))}
                    className={cn("cursor-pointer rounded-full border bg-transparent px-2 py-0.5 text-[10px] font-semibold outline-none", c.status === "done" ? "border-hl bg-hl text-[#1c1c1b]" : c.status === "in-progress" ? "border-hl/60 text-hl" : "border-line text-faint")}
                  >
                    {["planned", "in-progress", "done"].map((st) => (
                      <option key={st} className="bg-card text-ink">{st}</option>
                    ))}
                  </select>
                  <span className="min-w-0 flex-1 truncate text-[13px] font-medium text-ink">{c.title}</span>
                  {c.platform && <span className="text-[11px] text-faint">{c.platform}</span>}
                  <button onClick={async () => setData(await deleteCourse(c.id))} className="rounded p-1 text-faint hover:text-hl">
                    <Trash2 size={12} />
                  </button>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    type="range" min={0} max={100} step={5} value={c.progress}
                    onChange={async (e) => setData(await upsertCourse({ id: c.id, title: c.title, platform: c.platform, status: c.status, progress: Number(e.target.value), url: c.url }))}
                    className="h-1 flex-1 cursor-pointer accent-hl"
                  />
                  <span className="w-9 text-right text-[10px] text-faint tabular-nums">{c.progress}%</span>
                </div>
              </div>
            ))}
            {data.courses.length === 0 && (
              <p className="text-[13px] text-faint">no courses tracked. one at a time beats five at once.</p>
            )}
          </div>
        </div>

        {/* cert path */}
        <div className="card p-5">
          <h2 className="font-hand text-[26px] font-semibold text-ink">the cert path</h2>
          <form
            className="mt-3 flex gap-2"
            onSubmit={async (e) => {
              e.preventDefault();
              if (!certName.trim()) return;
              setData(await upsertCert({ name: certName, targetDate: certDate }));
              setCertName("");
              setCertDate("");
            }}
          >
            <input className="field" placeholder="cert — e.g. Security+" value={certName} onChange={(e) => setCertName(e.target.value)} />
            <input type="date" className="field w-36" value={certDate} onChange={(e) => setCertDate(e.target.value)} title="target date" />
            <button className="btn-hl !px-3" type="submit"><Plus size={15} /></button>
          </form>
          <div className="relative mt-5 space-y-4 pl-6 before:absolute before:top-1 before:bottom-1 before:left-[7px] before:w-px before:bg-line">
            {certOrder.map((c) => (
              <div key={c.id} className="relative">
                <span
                  className={cn(
                    "absolute top-1 -left-6 h-[15px] w-[15px] rounded-full border-2",
                    c.status === "earned" ? "border-hl bg-hl" : c.status === "studying" ? "border-hl bg-bg" : c.status === "scheduled" ? "border-ink bg-bg" : "border-line bg-card2"
                  )}
                />
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[14px] font-semibold text-ink">{c.name}</span>
                  {c.targetDate && <span className="text-[11px] text-faint">→ {fmtDate(c.targetDate)}</span>}
                  <button onClick={async () => setData(await deleteCert(c.id))} className="rounded p-1 text-faint hover:text-hl">
                    <Trash2 size={12} />
                  </button>
                </div>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {CERT_STATUSES.map((st) => (
                    <button
                      key={st}
                      onClick={async () => setData(await upsertCert({ id: c.id, name: c.name, status: st, targetDate: c.targetDate, notes: c.notes }))}
                      className={cn("rounded-full border px-2 py-0.5 text-[10px] font-semibold transition-all", c.status === st ? statusChipClass(st) : "border-line text-faint hover:text-muted")}
                    >
                      {st}
                    </button>
                  ))}
                </div>
                {c.notes && <p className="mt-1 text-[11px] text-faint">{c.notes}</p>}
              </div>
            ))}
            {certOrder.length === 0 && (
              <p className="text-[13px] text-faint">no certs mapped. Security+ first, OSCP is the long game.</p>
            )}
          </div>
        </div>
      </div>

      {/* practice logs */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <h2 className="flex items-center gap-2 font-hand text-[26px] font-semibold text-ink">
            <Swords size={19} className="text-hl" /> ctf &amp; lab log
          </h2>
          <form
            className="mt-3 grid grid-cols-2 gap-2"
            onSubmit={async (e) => {
              e.preventDefault();
              if (!ctfName.trim()) return;
              setData(await addCtf({ eventName: ctfName, platform: ctfPlatform, challengesSolved: Number(ctfSolved) || 0, points: Number(ctfPoints) || 0, date: new Date().toISOString().slice(0, 10) }));
              setCtfName(""); setCtfPlatform(""); setCtfSolved(""); setCtfPoints("");
            }}
          >
            <input className="field col-span-2" placeholder="event / room / box — e.g. HTB 'Lame' or picoCTF 2024" value={ctfName} onChange={(e) => setCtfName(e.target.value)} />
            <input className="field" placeholder="platform" value={ctfPlatform} onChange={(e) => setCtfPlatform(e.target.value)} />
            <div className="flex gap-2">
              <input type="number" className="field" placeholder="solves" value={ctfSolved} onChange={(e) => setCtfSolved(e.target.value)} min={0} />
              <input type="number" className="field" placeholder="points" value={ctfPoints} onChange={(e) => setCtfPoints(e.target.value)} min={0} />
              <button className="btn-hl !px-3" type="submit"><Plus size={15} /></button>
            </div>
          </form>
          <div className="mt-4 space-y-2">
            {data.ctfs.slice(0, 6).map((c) => (
              <div key={c.id} className="group flex items-center gap-2 text-[13px]">
                <span className="text-faint">{c.date ? fmtDate(c.date) : ""}</span>
                <span className="min-w-0 flex-1 truncate text-ink">{c.eventName}</span>
                {c.platform && <span className="text-faint">{c.platform}</span>}
                <span className="font-semibold text-hl">{c.challengesSolved} solved</span>
                <button onClick={async () => setData(await deleteCtf(c.id))} className="rounded p-1 text-faint opacity-0 transition-opacity group-hover:opacity-100 hover:text-hl">
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="flex items-center gap-2 font-hand text-[26px] font-semibold text-ink">
            <Terminal size={19} className="text-hl" /> coding reps
          </h2>
          <form
            className="mt-3 flex gap-2"
            onSubmit={async (e) => {
              e.preventDefault();
              const n = Number(codeCount);
              if (!(n > 0)) return;
              setData(await logCoding({ date: new Date().toISOString().slice(0, 10), problemsSolved: n, platform: codePlatform }));
              setCodeCount("");
            }}
          >
            <input type="number" min={1} className="field w-28" placeholder="solved" value={codeCount} onChange={(e) => setCodeCount(e.target.value)} />
            <select className="field flex-1" value={codePlatform} onChange={(e) => setCodePlatform(e.target.value)}>
              {["leetcode", "hackerrank", "codewars", "codeforces", "other"].map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
            <button className="btn-hl" type="submit"><Plus size={15} /> today</button>
          </form>
          <div className="mt-4 space-y-2">
            {data.coding.slice(0, 6).map((c) => (
              <div key={c.id} className="group flex items-center gap-2 text-[13px]">
                <span className="text-faint">{fmtDate(c.date)}</span>
                <span className="min-w-0 flex-1 truncate text-ink">{c.platform || "problems"}</span>
                <span className="font-semibold text-hl">{c.problemsSolved}</span>
                <button onClick={async () => setData(await deleteCodingLog(c.id))} className="rounded p-1 text-faint opacity-0 transition-opacity group-hover:opacity-100 hover:text-hl">
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
            {data.coding.length === 0 && (
              <p className="text-[13px] text-faint">zero reps logged. two problems a day compounds.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
