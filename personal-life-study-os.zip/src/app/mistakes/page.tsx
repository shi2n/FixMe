"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, ArrowRight } from "lucide-react";
import {
  getMistakes,
  addMistake,
  deleteMistake,
} from "@/app/actions/logs";
import { cn, fmtDate, todayStr } from "@/lib/utils";
import type { MistakeData } from "@/lib/types";
import InsightsClient from "@/components/InsightsClient";

const CATEGORIES: { id: string; label: string }[] = [
  { id: "wasted-day", label: "wasted a day" },
  { id: "deadline", label: "missed deadline" },
  { id: "test", label: "failed test/lab" },
  { id: "procrastination", label: "procrastination spiral" },
  { id: "other", label: "other" },
];

export default function MistakesPage() {
  const [items, setItems] = useState<MistakeData[] | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("wasted-day");
  const [cause, setCause] = useState("");
  const [fix, setFix] = useState("");
  const [date, setDate] = useState(todayStr());
  const [tick, setTick] = useState(0);

  useEffect(() => {
    getMistakes().then(setItems).catch(() => setItems([]));
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setItems(await addMistake({ title, category, cause, fix, date }));
    setTitle("");
    setCause("");
    setFix("");
    setTick((t) => t + 1);
  };

  return (
    <div className="py-10">
      <h1 className="font-hand text-5xl font-bold text-ink">the mistake log</h1>
      <p className="mt-1 max-w-lg text-sm text-muted">
        every entry is structured: what happened, likely cause, one fix. after a
        few weeks the pattern engine on the right starts telling you things you
        couldn&apos;t see from inside the week.
      </p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        <div>
          <form onSubmit={submit} className="card p-5">
            <div className="flex gap-2">
              <input
                className="field"
                placeholder="what happened — one honest sentence"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
              <input
                type="date"
                className="field w-36"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {CATEGORIES.map((c) => (
                <button
                  type="button"
                  key={c.id}
                  onClick={() => setCategory(c.id)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-semibold transition-all",
                    category === c.id
                      ? "border-hl bg-hl text-[#1c1c1b]"
                      : "border-line text-muted hover:text-ink"
                  )}
                >
                  {c.label}
                </button>
              ))}
            </div>
            <div className="mt-3 grid gap-2 md:grid-cols-2">
              <input
                className="field"
                placeholder="likely cause — be specific: 'slept 4h', 'no plan'"
                value={cause}
                onChange={(e) => setCause(e.target.value)}
              />
              <input
                className="field"
                placeholder="one fix to try next time"
                value={fix}
                onChange={(e) => setFix(e.target.value)}
              />
            </div>
            <button type="submit" className="btn-hl mt-4">
              <Plus size={15} /> log it and move on
            </button>
          </form>

          <div className="mt-6 space-y-3">
            {!items?.length && (
              <p className="text-[13px] text-faint">
                {items === null ? "reading the log…" : "no entries — either a perfect week, or an unexamined one."}
              </p>
            )}
            {items?.map((m) => (
              <div key={m.id} className="card card-hover group p-4">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-faint">{fmtDate(m.date)}</span>
                  <span className="chip !py-0.5 !text-[10px]">
                    {CATEGORIES.find((c) => c.id === m.category)?.label ?? m.category}
                  </span>
                  <button
                    onClick={async () => setItems(await deleteMistake(m.id))}
                    className="ml-auto rounded p-1 text-faint opacity-0 transition-opacity group-hover:opacity-100 hover:text-hl"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
                <p className="mt-2 text-[15px] font-medium text-ink">{m.title}</p>
                <div className="mt-2 space-y-1 text-[13px]">
                  {m.cause && (
                    <p className="text-muted">
                      <span className="text-faint">because </span>
                      {m.cause}
                    </p>
                  )}
                  {m.fix && (
                    <p className="flex items-center gap-1.5 text-ink">
                      <ArrowRight size={12} className="shrink-0 text-hl" />
                      {m.fix}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="paper-note tilt-r mb-6 p-5">
            <p className="font-hand text-[22px] leading-snug">
              a mistake logged once is data. the same mistake logged five times
              is a pattern — and patterns have a fix.
            </p>
          </div>
          <h2 className="font-hand text-3xl font-semibold text-ink">
            the pattern engine
          </h2>
          <InsightsClient key={tick} compact />
        </div>
      </div>
    </div>
  );
}
