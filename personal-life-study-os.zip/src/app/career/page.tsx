"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, CircleCheck, CircleDashed, Ban, Briefcase, Link2, StickyNote } from "lucide-react";
import {
  getCareer,
  addGoal,
  updateGoal,
  deleteGoal,
  addApplication,
  updateApplication,
  deleteApplication,
  addResume,
  deleteResume,
  type CareerData,
} from "@/app/actions/modules";
import { cn, fmtDate } from "@/lib/utils";

const STAGES = ["saved", "applied", "oa", "interview", "offer", "rejected"];

export default function CareerPage() {
  const [data, setData] = useState<CareerData | null>(null);

  // goal form
  const [goalTitle, setGoalTitle] = useState("");
  const [goalDate, setGoalDate] = useState("");

  // application form
  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");
  const [kind, setKind] = useState("internship");
  const [link, setLink] = useState("");
  const [skillsReq, setSkillsReq] = useState("");

  // resume form
  const [resumeLabel, setResumeLabel] = useState("");
  const [resumeNotes, setResumeNotes] = useState("");

  const reload = async () => setData(await getCareer());

  useEffect(() => {
    getCareer().then(setData).catch(() => setData({ goals: [], applications: [], resumes: [] }));
  }, []);

  if (!data) {
    return <p className="py-16 text-sm text-faint">opening the file…</p>;
  }

  const activeGoals = data.goals.filter((g) => g.status !== "done");

  const cycleGoal = async (id: number, status: string) => {
    const next = status === "active" ? "done" : status === "done" ? "dropped" : "active";
    setData(await updateGoal(id, { status: next }));
  };

  return (
    <div className="py-10">
      <h1 className="font-hand text-5xl font-bold text-ink">career</h1>
      <p className="mt-1 text-sm text-muted">
        internships don&apos;t apply themselves. track the pipeline, keep the
        resume honest, know what each posting actually asks for.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        {/* left column */}
        <div className="space-y-6">
          <div className="card p-5">
            <h2 className="font-hand text-[26px] font-semibold text-ink">goals</h2>
            <form
              className="mt-3 flex gap-2"
              onSubmit={async (e) => {
                e.preventDefault();
                if (!goalTitle.trim()) return;
                setData(await addGoal({ title: goalTitle, targetDate: goalDate, area: "career" }));
                setGoalTitle("");
                setGoalDate("");
              }}
            >
              <input
                className="field"
                placeholder="e.g. land a security internship for summer"
                value={goalTitle}
                onChange={(e) => setGoalTitle(e.target.value)}
              />
              <input
                type="date"
                className="field w-36"
                value={goalDate}
                onChange={(e) => setGoalDate(e.target.value)}
                title="target date"
              />
              <button className="btn-hl !px-3" type="submit">
                <Plus size={16} />
              </button>
            </form>
            <div className="mt-4 space-y-2">
              {data.goals.length === 0 && (
                <p className="text-[13px] text-faint">no goals yet. one honest sentence is enough.</p>
              )}
              {data.goals.map((g) => (
                <div key={g.id} className="group flex items-center gap-2.5 rounded-lg border border-line bg-bg-deep px-3 py-2.5">
                  <button
                    onClick={() => cycleGoal(g.id, g.status)}
                    title={`status: ${g.status} (click to change)`}
                    className={cn(
                      "shrink-0 transition-transform hover:scale-110",
                      g.status === "done" ? "text-hl" : g.status === "dropped" ? "text-faint" : "text-muted"
                    )}
                  >
                    {g.status === "done" ? <CircleCheck size={17} /> : g.status === "dropped" ? <Ban size={16} /> : <CircleDashed size={17} />}
                  </button>
                  <span
                    className={cn(
                      "min-w-0 flex-1 truncate text-sm",
                      g.status === "done" && "text-faint line-through",
                      g.status === "dropped" && "text-faint italic"
                    )}
                  >
                    {g.title}
                  </span>
                  {g.targetDate && (
                    <span className="shrink-0 text-[11px] text-faint">by {fmtDate(g.targetDate)}</span>
                  )}
                  <button
                    onClick={async () => setData(await deleteGoal(g.id))}
                    className="shrink-0 rounded p-1 text-faint opacity-0 transition-opacity group-hover:opacity-100 hover:text-hl"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>
            {activeGoals.length > 0 && (
              <p className="mt-3 text-[11px] text-faint">
                {data.goals.filter((g) => g.status === "done").length} done · {activeGoals.length} standing
              </p>
            )}
          </div>

          <div className="paper-note tilt-l p-5">
            <h2 className="font-hand text-[26px] font-semibold">
              resume versions
            </h2>
            <p className="mt-1 text-[12px] leading-snug text-[#6f6435]">
              every rewrite earns a line here — what changed and why. future-you
              will ask.
            </p>
            <form
              className="mt-3 space-y-2"
              onSubmit={async (e) => {
                e.preventDefault();
                if (!resumeLabel.trim()) return;
                setData(await addResume({ label: resumeLabel, notes: resumeNotes }));
                setResumeLabel("");
                setResumeNotes("");
              }}
            >
              <input
                className="field-paper"
                placeholder="v3 — security-focused rewrite"
                value={resumeLabel}
                onChange={(e) => setResumeLabel(e.target.value)}
              />
              <div className="flex gap-2">
                <input
                  className="field-paper"
                  placeholder="what changed: added HTB rank, cut the fluff"
                  value={resumeNotes}
                  onChange={(e) => setResumeNotes(e.target.value)}
                />
                <button type="submit" className="shrink-0 rounded-lg bg-[#3a3317] px-3.5 text-[#ece0af] transition-transform hover:-translate-y-0.5">
                  <Plus size={15} />
                </button>
              </div>
            </form>
            <div className="mt-3 space-y-1.5">
              {data.resumes.map((r) => (
                <div key={r.id} className="group flex items-center gap-2 text-[13px]">
                  <StickyNote size={13} className="shrink-0 text-[#6f6435]" />
                  <span className="min-w-0 flex-1 truncate font-medium">
                    {r.label}
                    {r.notes && <span className="font-normal text-[#6f6435]"> — {r.notes}</span>}
                  </span>
                  <button
                    onClick={async () => setData(await deleteResume(r.id))}
                    className="shrink-0 rounded p-1 text-[#8d7f52] opacity-0 transition-opacity group-hover:opacity-100 hover:text-[#3a3317]"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* applications */}
        <div className="card p-5">
          <h2 className="font-hand text-[26px] font-semibold text-ink">
            applications pipeline
          </h2>
          <form
            className="mt-3 grid gap-2"
            onSubmit={async (e) => {
              e.preventDefault();
              if (!company.trim()) return;
              setData(
                await addApplication({
                  company,
                  role,
                  kind,
                  link,
                  skillsRequired: skillsReq,
                  appliedAt: "",
                })
              );
              setCompany("");
              setRole("");
              setLink("");
              setSkillsReq("");
            }}
          >
            <div className="flex gap-2">
              <input
                className="field"
                placeholder="company"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
              />
              <input
                className="field"
                placeholder="role — soc analyst intern…"
                value={role}
                onChange={(e) => setRole(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <div className="flex overflow-hidden rounded-lg border border-line">
                {["internship", "job"].map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setKind(k)}
                    className={cn(
                      "px-3.5 py-2 text-xs font-semibold transition-colors",
                      kind === k ? "bg-hl text-[#1c1c1b]" : "bg-bg-deep text-muted"
                    )}
                  >
                    {k}
                  </button>
                ))}
              </div>
              <input
                className="field flex-1"
                placeholder="posting link (optional)"
                value={link}
                onChange={(e) => setLink(e.target.value)}
              />
              <input
                className="field flex-1"
                placeholder="skills they ask for: splunk, python, linux…"
                value={skillsReq}
                onChange={(e) => setSkillsReq(e.target.value)}
              />
              <button type="submit" className="btn-hl">
                <Plus size={15} /> track
              </button>
            </div>
          </form>

          <div className="mt-5 space-y-3">
            {data.applications.length === 0 && (
              <p className="text-[13px] text-faint">
                the pipeline is empty — that&apos;s a number too. send one
                application before the week ends.
              </p>
            )}
            {data.applications.map((a) => (
              <div key={a.id} className="card-hover rounded-xl border border-line bg-bg-deep p-4 transition-all">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-[15px] font-semibold text-ink">
                      {a.company}
                      {a.role && <span className="font-normal text-muted"> — {a.role}</span>}
                    </p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-faint">
                      <span className="chip !py-0.5">{a.kind}</span>
                      {a.appliedAt && <span>applied {fmtDate(a.appliedAt)}</span>}
                      {a.link && (
                        <a
                          href={a.link}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-hl hover:underline"
                        >
                          <Link2 size={11} /> posting
                        </a>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={async () => setData(await deleteApplication(a.id))}
                    className="rounded p-1.5 text-faint hover:text-hl"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {STAGES.map((s) => (
                    <button
                      key={s}
                      onClick={async () => setData(await updateApplication(a.id, { stage: s }))}
                      className={cn(
                        "rounded-full px-2.5 py-1 text-[11px] font-semibold transition-all",
                        a.stage === s
                          ? s === "offer"
                            ? "bg-hl text-[#1c1c1b]"
                            : s === "rejected"
                              ? "bg-card2 text-faint line-through"
                              : "border border-hl/70 text-hl"
                          : "border border-line text-faint hover:text-muted"
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>

                {a.skillsRequired && (
                  <p className="mt-2.5 text-[12px] text-muted">
                    <Briefcase size={11} className="mr-1 inline text-faint" />
                    asks for: {a.skillsRequired} — match these in the skills
                    tracker before the interview.
                  </p>
                )}

                <textarea
                  className="field mt-3 resize-none !bg-card text-[12px]"
                  rows={2}
                  placeholder="interview prep notes: questions they asked, what to study next…"
                  defaultValue={a.prepNotes}
                  onBlur={async (e) => {
                    if (e.target.value !== a.prepNotes) {
                      setData(await updateApplication(a.id, { prepNotes: e.target.value }));
                    }
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
