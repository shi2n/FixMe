"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, ChevronLeft, ChevronRight, PiggyBank, PencilLine, Check } from "lucide-react";
import {
  getFinance,
  addTransaction,
  deleteTransaction,
  saveFinanceSettings,
  type FinanceData,
} from "@/app/actions/modules";
import { cn, money, fmtDate, todayStr } from "@/lib/utils";

const CATEGORIES = [
  "food",
  "transport",
  "rent",
  "study & certs",
  "fun",
  "subscriptions",
  "health",
  "misc",
];

function monthLabel(m: string): string {
  const d = new Date(`${m}-01T00:00:00`);
  return d.toLocaleDateString("en-GB", { month: "long", year: "numeric" });
}

function shiftMonth(m: string, delta: number): string {
  const d = new Date(`${m}-01T00:00:00`);
  d.setMonth(d.getMonth() + delta);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export default function FinancePage() {
  const [month, setMonth] = useState(todayStr().slice(0, 7));
  const [data, setData] = useState<FinanceData | null>(null);

  const [kind, setKind] = useState<"expense" | "income">("expense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("food");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(todayStr());

  const [editFin, setEditFin] = useState(false);
  const [goalName, setGoalName] = useState("");
  const [goalAmount, setGoalAmount] = useState("");
  const [savedSoFar, setSavedSoFar] = useState("");
  const [monthlyBudget, setMonthlyBudget] = useState("");
  const [currency, setCurrency] = useState("$");

  const load = async (m: string) => {
    const d = await getFinance(m);
    setData(d);
    setGoalName(d.settings.savingsGoalName);
    setGoalAmount(String(d.settings.savingsGoalAmount || ""));
    setSavedSoFar(String(d.settings.savedSoFar || ""));
    setMonthlyBudget(String(d.settings.monthlyBudget || ""));
    setCurrency(d.settings.currency);
  };

  useEffect(() => {
    load(month).catch(() => {});
  }, [month]);

  if (!data) return <p className="py-16 text-sm text-faint">counting…</p>;

  const income = data.transactions.filter((t) => t.kind === "income").reduce((a, t) => a + t.amount, 0);
  const expense = data.transactions.filter((t) => t.kind === "expense").reduce((a, t) => a + t.amount, 0);
  const net = income - expense;
  const cur = data.settings.currency;
  const budgetPct = data.settings.monthlyBudget > 0 ? Math.min(100, (expense / data.settings.monthlyBudget) * 100) : 0;
  const overBudget = data.settings.monthlyBudget > 0 && expense > data.settings.monthlyBudget;
  const goalPct = data.settings.savingsGoalAmount > 0 ? Math.min(100, (data.settings.savedSoFar / data.settings.savingsGoalAmount) * 100) : 0;

  // group by date
  const groups: { date: string; items: FinanceData["transactions"] }[] = [];
  for (const t of data.transactions) {
    const g = groups.find((x) => x.date === t.date);
    if (g) g.items.push(t);
    else groups.push({ date: t.date, items: [t] });
  }

  return (
    <div className="py-10">
      <h1 className="font-hand text-5xl font-bold text-ink">money</h1>
      <p className="mt-1 text-sm text-muted">
        money in, money out, no mystery. manual on purpose — your bank stays out
        of it.
      </p>

      {/* month nav + summary */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button className="btn-ghost !px-2.5 !py-2" onClick={() => setMonth(shiftMonth(month, -1))}>
            <ChevronLeft size={15} />
          </button>
          <span className="min-w-40 text-center font-hand text-2xl font-semibold text-ink">
            {monthLabel(month)}
          </span>
          <button className="btn-ghost !px-2.5 !py-2" onClick={() => setMonth(shiftMonth(month, 1))}>
            <ChevronRight size={15} />
          </button>
        </div>
        <div className="flex gap-6 text-sm">
          <div>
            <p className="text-[11px] text-faint">in</p>
            <p className="text-lg font-bold text-hl">+{money(income, cur)}</p>
          </div>
          <div>
            <p className="text-[11px] text-faint">out</p>
            <p className="text-lg font-bold text-ink">−{money(expense, cur)}</p>
          </div>
          <div>
            <p className="text-[11px] text-faint">net</p>
            <p className={cn("text-lg font-bold", net >= 0 ? "text-hl" : "text-ink line-through decoration-hl/70")}>
              {net >= 0 ? "+" : "−"}{money(Math.abs(net), cur)}
            </p>
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        <div className="space-y-6">
          {/* add transaction */}
          <div className="card p-5">
            <form
              className="flex flex-wrap items-end gap-2"
              onSubmit={async (e) => {
                e.preventDefault();
                const amt = Number(amount);
                if (!(amt > 0)) return;
                setData(await addTransaction({ kind, amount: amt, category, note, date }));
                setAmount("");
                setNote("");
              }}
            >
              <div className="flex overflow-hidden rounded-lg border border-line">
                {(["expense", "income"] as const).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setKind(k)}
                    className={cn(
                      "px-4 py-2.5 text-xs font-bold transition-colors",
                      kind === k ? "bg-hl text-[#1c1c1b]" : "bg-bg-deep text-muted"
                    )}
                  >
                    {k}
                  </button>
                ))}
              </div>
              <div className="w-28">
                <label className="label">amount</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  className="field"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>
              <div>
                <label className="label">category</label>
                <select className="field" value={category} onChange={(e) => setCategory(e.target.value)}>
                  {CATEGORIES.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div className="min-w-40 flex-1">
                <label className="label">note</label>
                <input className="field" placeholder="what was it" value={note} onChange={(e) => setNote(e.target.value)} />
              </div>
              <div>
                <label className="label">date</label>
                <input type="date" className="field" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <button type="submit" className="btn-hl">
                <Plus size={15} /> log
              </button>
            </form>
          </div>

          {/* transactions list */}
          <div className="card p-5">
            <h2 className="font-hand text-[26px] font-semibold text-ink">the ledger</h2>
            {groups.length === 0 && (
              <p className="mt-3 text-[13px] text-faint">
                nothing logged in {monthLabel(month)}.
              </p>
            )}
            {groups.map((g) => (
              <div key={g.date} className="mt-4">
                <p className="text-[11px] font-semibold tracking-wide text-faint">{fmtDate(g.date)}</p>
                <div className="mt-1 divide-y divide-line/60">
                  {g.items.map((t) => (
                    <div key={t.id} className="group flex items-center gap-3 py-2.5">
                      <span className="chip shrink-0 !text-[10px]">{t.category}</span>
                      <span className="min-w-0 flex-1 truncate text-sm text-muted">{t.note || "—"}</span>
                      <span
                        className={cn(
                          "shrink-0 text-sm font-bold tabular-nums",
                          t.kind === "income" ? "text-hl" : "text-ink"
                        )}
                      >
                        {t.kind === "income" ? "+" : "−"}{money(t.amount, cur)}
                      </span>
                      <button
                        onClick={async () => setData(await deleteTransaction(t.id, month))}
                        className="shrink-0 rounded p-1 text-faint opacity-0 transition-opacity group-hover:opacity-100 hover:text-hl"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* right: budget + savings */}
        <div className="space-y-6">
          {data.settings.monthlyBudget > 0 && (
            <div className="card p-5">
              <div className="flex items-center justify-between">
                <h2 className="font-hand text-[26px] font-semibold text-ink">monthly budget</h2>
                <span className="text-xs text-faint">
                  {money(expense, cur)} of {money(data.settings.monthlyBudget, cur)}
                </span>
              </div>
              <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-bg-deep">
                <div
                  className={cn("h-full rounded-full transition-all duration-700", overBudget ? "bg-ink" : "bg-hl")}
                  style={{ width: `${budgetPct}%` }}
                />
              </div>
              <p className="mt-2 text-[12px] text-muted">
                {overBudget
                  ? `over by ${money(expense - data.settings.monthlyBudget, cur)}. not a lecture — just a fact.`
                  : `${money(data.settings.monthlyBudget - expense, cur)} left. slow down before the last week, not during it.`}
              </p>
            </div>
          )}

          <div className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 font-hand text-[26px] font-semibold text-ink">
                <PiggyBank size={20} className="text-hl" /> the plan
              </h2>
              <button
                onClick={async () => {
                  if (editFin) {
                    await saveFinanceSettings({
                      savingsGoalName: goalName,
                      savingsGoalAmount: Number(goalAmount) || 0,
                      savedSoFar: Number(savedSoFar) || 0,
                      monthlyBudget: Number(monthlyBudget) || 0,
                      currency: currency || "$",
                    });
                    await load(month);
                  }
                  setEditFin(!editFin);
                }}
                className="btn-ghost !px-3 !py-1.5 text-xs"
              >
                {editFin ? <><Check size={13} /> save</> : <><PencilLine size={13} /> edit</>}
              </button>
            </div>

            {editFin ? (
              <div className="mt-4 grid grid-cols-2 gap-2.5">
                <div className="col-span-2">
                  <label className="label">savings goal name</label>
                  <input className="field" placeholder="OSCP exam fund" value={goalName} onChange={(e) => setGoalName(e.target.value)} />
                </div>
                <div>
                  <label className="label">goal amount</label>
                  <input type="number" className="field" value={goalAmount} onChange={(e) => setGoalAmount(e.target.value)} />
                </div>
                <div>
                  <label className="label">saved so far</label>
                  <input type="number" className="field" value={savedSoFar} onChange={(e) => setSavedSoFar(e.target.value)} />
                </div>
                <div>
                  <label className="label">monthly budget</label>
                  <input type="number" className="field" value={monthlyBudget} onChange={(e) => setMonthlyBudget(e.target.value)} />
                </div>
                <div>
                  <label className="label">currency</label>
                  <input className="field" value={currency} onChange={(e) => setCurrency(e.target.value)} />
                </div>
              </div>
            ) : data.settings.savingsGoalAmount > 0 ? (
              <div className="mt-4">
                <div className="flex items-end justify-between">
                  <p className="text-sm font-semibold text-ink">{data.settings.savingsGoalName || "savings goal"}</p>
                  <p className="text-xs text-faint">
                    {money(data.settings.savedSoFar, cur)} / {money(data.settings.savingsGoalAmount, cur)}
                  </p>
                </div>
                <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-bg-deep">
                  <div className="h-full rounded-full bg-hl transition-all duration-700" style={{ width: `${goalPct}%` }} />
                </div>
                <p className="mt-2 font-hand text-xl text-ink">{Math.round(goalPct)}% there.</p>
              </div>
            ) : (
              <p className="mt-3 text-[13px] text-faint">
                no goal or budget set. hit edit — even a small goal makes the
                ledger mean something.
              </p>
            )}
          </div>

          <div className="paper-note tilt-r p-5">
            <p className="font-hand text-[22px] leading-snug">
              the OSCP costs money. the fund comes first — the cert follows
              the fund, not the other way round.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
