import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Caveat, Space_Grotesk } from "next/font/google";
import "./globals.css";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import RegisterSW from "@/components/RegisterSW";
import NudgeManager from "@/components/NudgeManager";

const caveat = Caveat({
  subsets: ["latin"],
  variable: "--font-caveat",
  weight: ["400", "500", "600", "700"],
});

const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
});

export const metadata: Metadata = {
  title: {
    default: "FixMe — track the mess, then fix it",
    template: "%s · FixMe",
  },
  description:
    "A private notebook that tracks your sleep, mood, study, money, skills and mistakes — then tells you honestly what today can hold.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "FixMe",
  },
  icons: {
    icon: [{ url: "/icon-512.png", type: "image/png" }],
    apple: [{ url: "/icon-512.png" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#1c1c1b",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${caveat.variable} ${grotesk.variable}`}>
      <body className="min-h-screen font-sans antialiased">
        <RegisterSW />
        <Nav />
        <main className="mx-auto w-full max-w-6xl px-4">{children}</main>
        <Footer />
        <NudgeManager />
      </body>
    </html>
  );
}
