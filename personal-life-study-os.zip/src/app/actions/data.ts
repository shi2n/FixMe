"use server";

import { db } from "@/db";
import { profile, checkins, mistakes } from "@/db/schema";
import { desc, eq, gte } from "drizzle-orm";
import { todayStr, daysAgoStr } from "@/lib/utils";
import {
  computeCapacity,
  capacityTemplateMessage,
  type Capacity,
} from "@/lib/capacity";
import { computeInsights, type Insight } from "@/lib/insights";
import type { CheckinData, ProfileData } from "@/lib/types";

function toProfile(r: typeof profile.$inferSelect): ProfileData {
  return {
    id: r.id,
    name: r.name ?? "",
    age: r.age,
    gender: r.gender ?? "",
    country: r.country ?? "",
    city: r.city ?? "",
    timezone: r.timezone ?? "",
    heightCm: r.heightCm,
    typicalSleepHours: r.typicalSleepHours,
    usualBedtime: r.usualBedtime ?? "23:00",
    usualWakeTime: r.usualWakeTime ?? "07:00",
    educationLevel: r.educationLevel ?? "",
    focusAreas: r.focusAreas ?? "",
    existingSkills: r.existingSkills ?? "",
    skillGaps: r.skillGaps ?? "",
    healthNotes: r.healthNotes ?? "",
    badHabits: r.badHabits ?? "",
    motivationStyle: r.motivationStyle ?? "balanced",
    onboarded: r.onboarded ?? false,
  };
}

function toCheckin(r: typeof checkins.$inferSelect): CheckinData {
  return {
    id: r.id,
    date: r.date,
    sleepHours: r.sleepHours,
    sleepQuality: r.sleepQuality,
    bedtime: r.bedtime,
    mood: r.mood,
    energy: r.energy,
    emotionalLoad: r.emotionalLoad,
    illness: r.illness,
    studyMinutes: r.studyMinutes,
    exerciseDone: r.exerciseDone,
    exerciseType: r.exerciseType,
    distraction: r.distraction,
  };
}

export async function getProfile(): Promise<ProfileData> {
  const rows = await db.select().from(profile).limit(1);
  if (rows[0]) return toProfile(rows[0]);
  const inserted = await db.insert(profile).values({}).returning();
  return toProfile(inserted[0]);
}

export async function saveProfile(
  patch: Partial<Omit<ProfileData, "id">>
): Promise<ProfileData> {
  const cur = await getProfile();
  await db
    .update(profile)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(profile.id, cur.id));
  return getProfile();
}

export async function getCheckin(date: string): Promise<CheckinData | null> {
  const rows = await db
    .select()
    .from(checkins)
    .where(eq(checkins.date, date))
    .limit(1);
  return rows[0] ? toCheckin(rows[0]) : null;
}

export async function listCheckins(days = 45): Promise<CheckinData[]> {
  const from = daysAgoStr(days - 1);
  const rows = await db
    .select()
    .from(checkins)
    .where(gte(checkins.date, from))
    .orderBy(desc(checkins.date));
  return rows.map(toCheckin);
}

type CheckinPatch = Partial<Omit<CheckinData, "id" | "date">> & {
  date: string;
};

export async function saveCheckin(patch: CheckinPatch): Promise<CheckinData> {
  const { date, ...rest } = patch;
  const clean: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(rest)) {
    if (v !== undefined) clean[k] = v;
  }
  await db
    .insert(checkins)
    .values({ date, ...clean })
    .onConflictDoUpdate({
      target: checkins.date,
      set: { ...clean, updatedAt: new Date() },
    });
  return (await getCheckin(date))!;
}

export async function addStudyMinutes(minutes: number): Promise<CheckinData> {
  const date = todayStr();
  const existing = await getCheckin(date);
  const next = (existing?.studyMinutes ?? 0) + Math.max(0, Math.round(minutes));
  return saveCheckin({ date, studyMinutes: next });
}

export interface WeekPoint {
  date: string;
  label: string;
  study: number; // minutes
  sleep: number | null; // hours
  mood: number | null;
}

export interface TodayStatus {
  studyMinutes: number;
  capacityMinutes: number;
  exerciseDone: boolean;
  heavy: boolean;
}

/** Cheap status read for the background nudge checker (no AI calls). */
export async function getTodayStatus(): Promise<TodayStatus> {
  const p = await getProfile();
  const recent = await listCheckins(14);
  const today = recent.find((r) => r.date === todayStr()) ?? null;
  const cap = computeCapacity({ profile: p, today, recent });
  return {
    studyMinutes: today?.studyMinutes ?? 0,
    capacityMinutes: cap.minutes,
    exerciseDone: !!today?.exerciseDone,
    heavy: !!(today?.emotionalLoad && today.emotionalLoad.trim()),
  };
}

export interface DashboardData {
  profile: ProfileData;
  today: CheckinData | null;
  recent: CheckinData[];
  capacity: Capacity;
  message: string;
  insights: Insight[];
  week: WeekPoint[];
  mistakeCount: number;
}

export async function getDashboard(): Promise<DashboardData> {
  const p = await getProfile();
  const recent = await listCheckins(45);
  const today = recent.find((r) => r.date === todayStr()) ?? null;
  const capacity = computeCapacity({ profile: p, today, recent });
  const message = capacityTemplateMessage(
    capacity,
    p.motivationStyle,
    today?.sleepHours ?? null
  );

  const mrows = await db
    .select()
    .from(mistakes)
    .orderBy(desc(mistakes.date))
    .limit(30);

  const insights = computeInsights(
    recent,
    mrows.map((m) => ({ date: m.date, category: m.category ?? "other", cause: m.cause ?? "" }))
  );

  const byDate = new Map(recent.map((r) => [r.date, r]));
  const week: WeekPoint[] = [];
  for (let i = 13; i >= 0; i--) {
    const date = daysAgoStr(i);
    const c = byDate.get(date);
    const d = new Date(`${date}T00:00:00`);
    week.push({
      date,
      label: d.toLocaleDateString("en-GB", { weekday: "narrow" }),
      study: c?.studyMinutes ?? 0,
      sleep: c?.sleepHours ?? null,
      mood: c?.mood ?? null,
    });
  }

  const mcount = await db
    .select({ id: mistakes.id })
    .from(mistakes)
    .orderBy(desc(mistakes.date))
    .limit(200);

  return {
    profile: p,
    today,
    recent,
    capacity,
    message,
    insights,
    week,
    mistakeCount: mcount.length,
  };
}
