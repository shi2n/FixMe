"use server";

import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { encryptSecret } from "@/lib/crypto";
import {
  getAiCredentials,
  testProviderConnection,
  type AiProvider,
  type ProviderChoice,
} from "@/lib/ai";
import type { SettingsData } from "@/lib/types";

async function ensureSettingsRow() {
  const rows = await db.select().from(settings).limit(1);
  if (rows[0]) return rows[0];
  const inserted = await db.insert(settings).values({}).returning();
  return inserted[0];
}

export async function getSettings(): Promise<SettingsData> {
  const s = await ensureSettingsRow();
  // Never return the key itself — only whether one exists.
  let hasKey = !!s.apiKeyEnc;
  if (!hasKey) {
    const creds = await getAiCredentials();
    hasKey = !!creds; // env-provided key counts as configured
  }
  return {
    provider: s.provider ?? "none",
    hasKey,
    nudgesEnabled: s.nudgesEnabled ?? false,
    studyNudgeTime: s.studyNudgeTime ?? "17:00",
    capNudges: s.capNudges ?? true,
    exerciseNudgeTime: s.exerciseNudgeTime ?? "",
    readingNudgeTime: s.readingNudgeTime ?? "",
  };
}

export async function saveProvider(
  provider: ProviderChoice
): Promise<SettingsData> {
  const s = await ensureSettingsRow();
  await db.update(settings).set({ provider }).where(eq(settings.id, s.id));
  return getSettings();
}

export async function saveApiKey(apiKey: string): Promise<SettingsData> {
  const s = await ensureSettingsRow();
  const trimmed = apiKey.trim();
  if (trimmed.length >= 8) {
    await db
      .update(settings)
      .set({ apiKeyEnc: encryptSecret(trimmed) })
      .where(eq(settings.id, s.id));
  }
  return getSettings();
}

export async function clearApiKey(): Promise<SettingsData> {
  const s = await ensureSettingsRow();
  await db.update(settings).set({ apiKeyEnc: null }).where(eq(settings.id, s.id));
  return getSettings();
}

export async function testConnection(): Promise<{
  ok: boolean;
  detail: string;
}> {
  const creds = await getAiCredentials();
  if (!creds) {
    return {
      ok: false,
      detail:
        "No key found. Paste one above and save, or set an OPENAI_API_KEY / ANTHROPIC_API_KEY / GEMINI_API_KEY environment variable.",
    };
  }
  return testProviderConnection(creds.provider as AiProvider, creds.apiKey);
}

export async function saveNudges(patch: {
  nudgesEnabled?: boolean;
  studyNudgeTime?: string;
  capNudges?: boolean;
  exerciseNudgeTime?: string;
  readingNudgeTime?: string;
}): Promise<SettingsData> {
  const s = await ensureSettingsRow();
  await db.update(settings).set(patch).where(eq(settings.id, s.id));
  return getSettings();
}
