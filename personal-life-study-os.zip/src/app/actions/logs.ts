"use server";

import { db } from "@/db";
import { mistakes, books, notes } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { todayStr } from "@/lib/utils";
import type { BookData, MistakeData, NoteData } from "@/lib/types";

// ------------------------------ mistakes ------------------------------

export async function getMistakes(): Promise<MistakeData[]> {
  const rows = await db
    .select()
    .from(mistakes)
    .orderBy(desc(mistakes.date), desc(mistakes.id))
    .limit(120);
  return rows.map((m) => ({
    id: m.id,
    date: m.date,
    title: m.title,
    category: m.category ?? "other",
    cause: m.cause ?? "",
    fix: m.fix ?? "",
  }));
}

export async function addMistake(data: {
  title: string;
  category?: string;
  cause?: string;
  fix?: string;
  date?: string;
}): Promise<MistakeData[]> {
  if (data.title.trim()) {
    await db.insert(mistakes).values({
      title: data.title.trim(),
      category: data.category ?? "other",
      cause: data.cause ?? "",
      fix: data.fix ?? "",
      date: data.date ?? todayStr(),
    });
  }
  return getMistakes();
}

export async function deleteMistake(id: number): Promise<MistakeData[]> {
  await db.delete(mistakes).where(eq(mistakes.id, id));
  return getMistakes();
}

// ------------------------------ reading list ------------------------------

const CURATED_BOOKS: Omit<BookData, "id">[] = [
  {
    title: "Hacking: The Art of Exploitation",
    author: "Jon Erickson",
    category: "cyber",
    why: "The book that actually makes you understand memory, not just run tools. Slow, dense, worth it.",
    status: "to-read",
    source: "curated",
  },
  {
    title: "The Web Application Hacker's Handbook",
    author: "Dafydd Stuttard & Marcus Pinto",
    category: "cyber",
    why: "The web-bug bible. Read it alongside PortSwigger Academy labs, not instead of them.",
    status: "to-read",
    source: "curated",
  },
  {
    title: "Practical Malware Analysis",
    author: "Michael Sikorski & Andrew Honig",
    category: "cyber",
    why: "Hands-on reversing for the blue-team-curious. The labs alone justify it.",
    status: "to-read",
    source: "curated",
  },
  {
    title: "The Pragmatic Programmer",
    author: "David Thomas & Andrew Hunt",
    category: "cs",
    why: "How to think like an engineer instead of a tutorial-follower. Read early, re-read yearly.",
    status: "to-read",
    source: "curated",
  },
  {
    title: "Deep Work",
    author: "Cal Newport",
    category: "personal",
    why: "The case for long, undistracted focus — the skill underneath every other skill on this list.",
    status: "to-read",
    source: "curated",
  },
  {
    title: "Atomic Habits",
    author: "James Clear",
    category: "personal",
    why: "Systems over motivation. Useful when willpower runs out, which it always does.",
    status: "to-read",
    source: "curated",
  },
  {
    title: "The Obstacle Is the Way",
    author: "Ryan Holiday",
    category: "personal",
    why: "For the weeks when everything breaks at once. Stoicism without the lecture.",
    status: "to-read",
    source: "curated",
  },
];

export async function getBooks(): Promise<BookData[]> {
  const rows = await db.select().from(books).orderBy(desc(books.createdAt));
  if (rows.length === 0) {
    await db.insert(books).values(
      CURATED_BOOKS.map((b) => ({
        title: b.title,
        author: b.author,
        category: b.category,
        why: b.why,
        status: b.status,
        source: b.source,
      }))
    );
    return getBooks();
  }
  return rows.map((b) => ({
    id: b.id,
    title: b.title,
    author: b.author ?? "",
    category: b.category ?? "personal",
    why: b.why ?? "",
    status: b.status ?? "to-read",
    source: b.source ?? "manual",
  }));
}

export async function addBook(data: {
  title: string;
  author?: string;
  category?: string;
  why?: string;
  source?: string;
}): Promise<BookData[]> {
  if (data.title.trim()) {
    await db.insert(books).values({
      title: data.title.trim(),
      author: data.author ?? "",
      category: data.category ?? "personal",
      why: data.why ?? "",
      source: data.source ?? "manual",
    });
  }
  return getBooks();
}

export async function updateBook(
  id: number,
  patch: Partial<Pick<BookData, "status" | "why" | "category">>
): Promise<BookData[]> {
  await db.update(books).set(patch).where(eq(books.id, id));
  return getBooks();
}

export async function deleteBook(id: number): Promise<BookData[]> {
  await db.delete(books).where(eq(books.id, id));
  return getBooks();
}

// ------------------------------ notes & practice ------------------------------

function toNote(n: typeof notes.$inferSelect): NoteData {
  return {
    id: n.id,
    kind: n.kind ?? "note",
    title: n.title ?? "",
    content: n.content ?? "",
    createdAt: n.createdAt?.toISOString() ?? "",
    updatedAt: n.updatedAt?.toISOString() ?? "",
  };
}

export async function getNotes(): Promise<NoteData[]> {
  const rows = await db
    .select()
    .from(notes)
    .orderBy(desc(notes.updatedAt))
    .limit(150);
  return rows.map(toNote);
}

export async function createNote(kind: string): Promise<NoteData[]> {
  await db.insert(notes).values({
    kind: kind === "practice" ? "practice" : "note",
    title: "",
    content: "",
  });
  return getNotes();
}

export async function updateNote(
  id: number,
  patch: { title?: string; content?: string }
): Promise<void> {
  await db
    .update(notes)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(notes.id, id));
}

export async function deleteNote(id: number): Promise<NoteData[]> {
  await db.delete(notes).where(eq(notes.id, id));
  return getNotes();
}
