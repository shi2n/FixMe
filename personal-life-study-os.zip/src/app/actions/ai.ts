"use server";

import { db } from "@/db";
import {
  profile,
  checkins,
  mistakes,
  transactions,
  skills,
  books,
} from "@/db/schema";
import { desc, gte, like } from "drizzle-orm";
import { todayStr, daysAgoStr, fmtHours, money } from "@/lib/utils";
import {
  computeCapacity,
  capacityTemplateMessage,
  COACH_SYSTEM,
  type Capacity,
} from "@/lib/capacity";
import { computeInsights, type Insight } from "@/lib/insights";
import { aiComplete, getAiCredentials } from "@/lib/ai";
import type { BookData } from "@/lib/types";

function styleLine(style: string): string {
  if (style === "tough") return "Tone: tough-love. Direct, challenging, no coddling — but on their side.";
  if (style === "gentle") return "Tone: gentle. Warm, validating, tiny concrete steps. If heavy emotions are present, lead with care, not productivity.";
  return "Tone: balanced. Honest but kind.";
}

// -------------------- daily capacity (AI-phrased) --------------------

export interface DailyCoachResult {
  capacity: Capacity;
  message: string;
  aiPowered: boolean;
}

export async function getDailyCoach(): Promise<DailyCoachResult> {
  const pRows = await db.select().from(profile).limit(1);
  const p = pRows[0] ?? null;
  const recent = await db
    .select()
    .from(checkins)
    .where(gte(checkins.date, daysAgoStr(44)))
    .orderBy(desc(checkins.date));
  const today = recent.find((r) => r.date === todayStr()) ?? null;

  const capacity = computeCapacity({ profile: p, today, recent });
  const style = p?.motivationStyle ?? "balanced";
  const creds = await getAiCredentials();

  let message = "";
  if (creds) {
    const prompt = `${styleLine(style)}
Today's computed study capacity and why:
- Realistic capacity: ${capacity.hours} focused hours (mode: ${capacity.mode})
- Logged sleep: ${today?.sleepHours ?? "not logged"} h, quality ${today?.sleepQuality ?? "-"}/5
- Mood ${today?.mood ?? "-"}/5, energy ${today?.energy ?? "-"}/5
- Emotionally heavy today: ${today?.emotionalLoad ? "yes (private)" : "no"}
- Ill or in pain: ${today?.illness ? "yes" : "no"}
- Study already logged today: ${fmtHours(today?.studyMinutes ?? 0)}
- Suggested peak window: ${capacity.peak.window} (${capacity.peak.label})
Write the daily coach read: name the realistic number, say why in plain words (mention the strongest 1-2 factors), and tell them exactly what kind of work to do and roughly when. If mode is recovery, be kind first and explicitly give lighter tasks (flashcards, review, no new hard material). Never invent data. Do not address them by a name you don't know.`;
    const out = await aiComplete({ system: COACH_SYSTEM, prompt, maxTokens: 190, temperature: 0.75 });
    if (out) message = out;
  }

  if (!message) {
    message = capacityTemplateMessage(capacity, style, today?.sleepHours ?? null);
  }
  return { capacity, message, aiPowered: !!creds && !!message && message !== capacityTemplateMessage(capacity, style, today?.sleepHours ?? null) };
}

// -------------------- ask your data --------------------

export interface AskResult {
  ok: boolean;
  needsKey: boolean;
  answer: string | null;
  groundedIn: string;
}

export async function askData(questionRaw: string): Promise<AskResult> {
  const question = questionRaw.trim().slice(0, 500);
  if (!question) return { ok: false, needsKey: false, answer: null, groundedIn: "" };

  const from = daysAgoStr(44);
  const [pRows, recent, mrows, txMonth, skillRows, bookRows] = await Promise.all([
    db.select().from(profile).limit(1),
    db.select().from(checkins).where(gte(checkins.date, from)).orderBy(desc(checkins.date)),
    db.select().from(mistakes).orderBy(desc(mistakes.date)).limit(20),
    db.select().from(transactions).where(like(transactions.date, `${todayStr().slice(0, 7)}%`)),
    db.select().from(skills).limit(80),
    db.select().from(books),
  ]);
  const p = pRows[0];
  const capacity = computeCapacity({ profile: p ?? null, today: recent.find((r) => r.date === todayStr()) ?? null, recent });

  const logLines = recent
    .map(
      (c) =>
        `${c.date} | sleep ${c.sleepHours ?? "?"}h(q${c.sleepQuality ?? "?"}) bed:${c.bedtime || "?"} | mood ${c.mood ?? "?"}/5 energy ${c.energy ?? "?"}/5 | studied ${c.studyMinutes ?? 0}min | exercise:${c.exerciseDone ? c.exerciseType || "yes" : "no"} | heavy:${c.emotionalLoad ? "yes" : "no"} | ill:${c.illness ? "yes" : "no"} | distracted-by:${(c.distraction ?? "").slice(0, 60) || "-"}`
    )
    .join("\n");

  const income = txMonth.filter((t) => t.kind === "income").reduce((a, t) => a + t.amount, 0);
  const expense = txMonth.filter((t) => t.kind === "expense").reduce((a, t) => a + t.amount, 0);

  const ctx = `PROFILE: ${p?.educationLevel || "CS student, cybersecurity"}; focus: ${p?.focusAreas || "general cyber"}; chronotype peak ${capacity.peak.window}.
TODAY: ${todayStr()}; today's realistic capacity ${capacity.hours}h (mode ${capacity.mode}); studied so far ${fmtHours(recent.find((r) => r.date === todayStr())?.studyMinutes ?? 0)}.
DAILY LOGS (last ${recent.length} days):
${logLines || "(no check-ins yet)"}
MISTAKES (recent): ${mrows.map((m) => `${m.date}: ${m.title} [${m.category}] cause:${m.cause || "?"} fix:${m.fix || "?"}`).join(" | ") || "none logged"}
FINANCE this month: income ${money(income)}, expenses ${money(expense)}.
SKILLS: ${skillRows.map((s) => `${s.name} (${s.domain}: ${s.status}, ${s.progress}%)`).slice(0, 40).join("; ") || "none yet"}
READING: ${bookRows.map((b) => `${b.title} [${b.status}]`).join("; ") || "empty"}`;

  const groundedIn = `${recent.length} check-ins, ${mrows.length} mistakes, ${txMonth.length} transactions, ${skillRows.length} skills`;
  const creds = await getAiCredentials();
  if (!creds) {
    return {
      ok: false,
      needsKey: true,
      answer: null,
      groundedIn,
    };
  }

  const answer = await aiComplete({
    system: `You are the private analyst for the user's own life-logging app. Answer using ONLY the data provided below — never invent numbers, dates or patterns that are not in the data. If the data can't answer the question, say exactly that and say what to start logging so it can. Be blunt, warm, second person, concrete. Use the actual numbers. Short. No emojis. 120 words max unless a breakdown is asked for.`,
    prompt: `QUESTION: ${question}\n\nDATA:\n${ctx}`,
    maxTokens: 420,
    temperature: 0.35,
  });

  if (!answer) {
    return { ok: false, needsKey: false, answer: "The AI provider didn't respond. Check your key in Settings and try again.", groundedIn };
  }
  return { ok: true, needsKey: false, answer, groundedIn };
}

// -------------------- pattern insights --------------------

export interface InsightsResult {
  insights: Insight[];
  narrative: string | null;
  aiPowered: boolean;
}

export async function getPatternInsights(): Promise<InsightsResult> {
  const from = daysAgoStr(44);
  const [recent, mrows] = await Promise.all([
    db.select().from(checkins).where(gte(checkins.date, from)).orderBy(desc(checkins.date)),
    db.select().from(mistakes).orderBy(desc(mistakes.date)).limit(30),
  ]);
  const insights = computeInsights(
    recent,
    mrows.map((m) => ({ date: m.date, category: m.category ?? "other", cause: m.cause ?? "" }))
  );

  const creds = await getAiCredentials();
  let narrative: string | null = null;
  if (creds && insights.length > 0 && insights[0].id !== "not-enough") {
    const stats = insights.map((i) => `- ${i.headline} (${i.stat ?? "n/a"}): ${i.body}`).join("\n");
    narrative = await aiComplete({
      system: COACH_SYSTEM,
      prompt: `${styleLine("balanced")}\nThese patterns were computed from my real logs:\n${stats}\nWrite a 3-sentence coach read: what the pattern really says about how I work, and the single highest-leverage change to make this week. Concrete, no fluff.`,
      maxTokens: 170,
      temperature: 0.75,
    });
  }
  return { insights, narrative, aiPowered: !!narrative };
}

// -------------------- nudges --------------------

const NUDGE_FALLBACKS: Record<string, string[]> = {
  study: [
    "Nothing logged yet. 25 minutes — one pomodoro — and the day isn't a write-off.",
    "The plan said study. The day isn't over. One round, starting now.",
    "Future-you is watching. Give them one focused 25 minutes.",
  ],
  studyGentle: [
    "Hey — no study logged yet. No guilt. One small 25-minute round whenever you're ready.",
    "A tiny start still counts. Open the notes, do one round, see how you feel.",
  ],
  cap: [
    "You've hit today's honest cap. Close the laptop. Rest is part of the plan, not a reward for skipping it.",
    "Target done. Stop now — burnout tomorrow helps nobody.",
  ],
  exercise: [
    "Body's been carrying your brain all day. 20 minutes of movement — go.",
  ],
  reading: [
    "Ten pages. That's the whole ask. Book's waiting.",
  ],
};

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export async function getNudge(
  kind: "study" | "cap" | "exercise" | "reading"
): Promise<{ message: string; aiPowered: boolean }> {
  const pRows = await db.select().from(profile).limit(1);
  const p = pRows[0];
  const style = p?.motivationStyle ?? "balanced";
  const today = await db
    .select()
    .from(checkins)
    .where(gte(checkins.date, todayStr()))
    .orderBy(desc(checkins.date))
    .limit(1);
  const t = today[0];
  const heavy = !!(t?.emotionalLoad && t.emotionalLoad.trim());

  const creds = await getAiCredentials();
  if (creds) {
    const kindBrief: Record<string, string> = {
      study: "They haven't logged any study time yet today and it's getting late. Nudge them to start one pomodoro.",
      cap: "They've hit their computed study cap for today. Tell them to stop, rest, and protect tomorrow.",
      exercise: "They set an exercise reminder and haven't logged exercise today.",
      reading: "Evening reading nudge: nudge them toward 10 pages of their current book.",
    };
    const out = await aiComplete({
      system: COACH_SYSTEM,
      prompt: `${styleLine(style)}
${kindBrief[kind]}
Today so far: sleep ${t?.sleepHours ?? "?"}h, mood ${t?.mood ?? "?"}/5, energy ${t?.energy ?? "?"}/5, studied ${fmtHours(t?.studyMinutes ?? 0)}, emotionally heavy day: ${heavy ? "yes — soften everything" : "no"}.
Write ONE short notification message (max 2 sentences, max 25 words). No greeting, no sign-off. If it's a heavy day, acknowledge them as a person first.`,
      maxTokens: 70,
      temperature: 0.85,
    });
    if (out) return { message: out.replace(/^"|"$/g, ""), aiPowered: true };
  }

  if (kind === "study" && heavy) return { message: "Rough day — noted. If all you can do is 10 easy minutes, that's still a win. Check in with yourself first.", aiPowered: false };
  if (kind === "study" && style === "gentle") return { message: pick(NUDGE_FALLBACKS.studyGentle), aiPowered: false };
  if (kind === "cap") return { message: pick(NUDGE_FALLBACKS.cap), aiPowered: false };
  if (kind === "exercise") return { message: pick(NUDGE_FALLBACKS.exercise), aiPowered: false };
  if (kind === "reading") return { message: pick(NUDGE_FALLBACKS.reading), aiPowered: false };
  return { message: pick(NUDGE_FALLBACKS.study), aiPowered: false };
}

// -------------------- book recommendations --------------------

export interface BookSuggestion {
  title: string;
  author: string;
  category: "cyber" | "cs" | "personal";
  why: string;
}

export interface BookSuggestResult {
  needsKey: boolean;
  suggestions: BookSuggestion[];
  error?: string;
}

export async function getBookSuggestions(): Promise<BookSuggestResult> {
  const creds = await getAiCredentials();
  if (!creds) return { needsKey: true, suggestions: [] };

  const [pRows, bookRows, recent] = await Promise.all([
    db.select().from(profile).limit(1),
    db.select().from(books),
    db.select().from(checkins).where(gte(checkins.date, daysAgoStr(13))).orderBy(desc(checkins.date)).limit(14),
  ]);
  const p = pRows[0];
  const have = bookRows.map((b) => `${b.title} by ${b.author}`).join("; ");
  const lowMoodDays = recent.filter((r) => (r.mood ?? 3) <= 2).length;
  const heavyDays = recent.filter((r) => r.emotionalLoad && r.emotionalLoad.trim()).length;

  const prompt = `Recommend exactly 4 real, well-reviewed, actually-published books for this person:
- Computer Science student specializing in cybersecurity. Focus areas: ${p?.focusAreas || "general security"}.
- Current skills: ${p?.existingSkills || "foundational"}. Known gaps: ${p?.skillGaps || "not listed"}.
- Last two weeks: ${lowMoodDays} low-mood days, ${heavyDays} emotionally heavy days out of ${recent.length} logged.
Mix: at least 1 hard cybersecurity/technical title, 1 CS/software-engineering craft title, and 1-2 titles for what they're personally going through (focus, discipline, emotional resilience) based on the mood signal.
Already on their list (do NOT repeat): ${have || "nothing yet"}.
Rules: real books only, real authors only — if unsure a book exists, do not include it. No hallucinated titles.
Respond with STRICT JSON only, an array of 4 objects with keys: title, author, category ("cyber"|"cs"|"personal"), why (one honest sentence, specific to them). No markdown fences, no commentary.`;

  const out = await aiComplete({ prompt, maxTokens: 600, temperature: 0.6 });
  if (!out) return { needsKey: false, suggestions: [], error: "No response from the AI provider." };

  try {
    const match = out.match(/\[[\s\S]*\]/);
    const parsed = JSON.parse(match ? match[0] : out) as BookSuggestion[];
    const clean = parsed
      .filter((b) => b && typeof b.title === "string" && b.title.trim())
      .slice(0, 4)
      .map((b) => ({
        title: String(b.title).trim(),
        author: String(b.author ?? "").trim(),
        category: (["cyber", "cs", "personal"].includes(b.category) ? b.category : "personal") as BookSuggestion["category"],
        why: String(b.why ?? "").trim(),
      }));
    if (clean.length === 0) return { needsKey: false, suggestions: [], error: "Couldn't parse the suggestions. Try again." };
    return { needsKey: false, suggestions: clean };
  } catch {
    return { needsKey: false, suggestions: [], error: "Couldn't parse the suggestions. Try again." };
  }
}

export type { BookData };
