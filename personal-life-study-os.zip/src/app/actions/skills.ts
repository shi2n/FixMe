"use server";

import { db } from "@/db";
import { skills, courses, certs, ctfEvents, codingLogs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import type {
  CertData,
  CodingLogData,
  CourseData,
  CtfData,
  SkillData,
} from "@/lib/types";

export interface SkillsData {
  skills: SkillData[];
  courses: CourseData[];
  certs: CertData[];
  ctfs: CtfData[];
  coding: CodingLogData[];
}

export async function getSkillsData(): Promise<SkillsData> {
  const [s, co, ce, ct, cl] = await Promise.all([
    db.select().from(skills).orderBy(desc(skills.createdAt)),
    db.select().from(courses).orderBy(desc(courses.createdAt)),
    db.select().from(certs).orderBy(desc(certs.createdAt)),
    db.select().from(ctfEvents).orderBy(desc(ctfEvents.date)),
    db.select().from(codingLogs).orderBy(desc(codingLogs.date)).limit(60),
  ]);
  return {
    skills: s.map((x) => ({
      id: x.id,
      domain: x.domain ?? "general",
      name: x.name,
      status: x.status ?? "learning",
      progress: x.progress ?? 0,
      notes: x.notes ?? "",
    })),
    courses: co.map((x) => ({
      id: x.id,
      title: x.title,
      platform: x.platform ?? "",
      status: x.status ?? "in-progress",
      progress: x.progress ?? 0,
      url: x.url ?? "",
    })),
    certs: ce.map((x) => ({
      id: x.id,
      name: x.name,
      status: x.status ?? "planned",
      targetDate: x.targetDate ?? "",
      notes: x.notes ?? "",
    })),
    ctfs: ct.map((x) => ({
      id: x.id,
      eventName: x.eventName,
      platform: x.platform ?? "",
      challengesSolved: x.challengesSolved ?? 0,
      points: x.points ?? 0,
      date: x.date ?? "",
      notes: x.notes ?? "",
    })),
    coding: cl.map((x) => ({
      id: x.id,
      date: x.date,
      problemsSolved: x.problemsSolved ?? 0,
      platform: x.platform ?? "",
    })),
  };
}

export async function upsertSkill(data: {
  id?: number;
  name: string;
  domain?: string;
  status?: string;
  progress?: number;
  notes?: string;
}): Promise<SkillsData> {
  const values = {
    name: data.name.trim(),
    domain: data.domain ?? "general",
    status: data.status ?? "learning",
    progress: Math.max(0, Math.min(100, data.progress ?? 0)),
    notes: data.notes ?? "",
  };
  if (!values.name) return getSkillsData();
  if (data.id) {
    await db.update(skills).set(values).where(eq(skills.id, data.id));
  } else {
    await db.insert(skills).values(values);
  }
  return getSkillsData();
}

export async function deleteSkill(id: number): Promise<SkillsData> {
  await db.delete(skills).where(eq(skills.id, id));
  return getSkillsData();
}

export async function upsertCourse(data: {
  id?: number;
  title: string;
  platform?: string;
  status?: string;
  progress?: number;
  url?: string;
}): Promise<SkillsData> {
  const values = {
    title: data.title.trim(),
    platform: data.platform ?? "",
    status: data.status ?? "in-progress",
    progress: Math.max(0, Math.min(100, data.progress ?? 0)),
    url: data.url ?? "",
  };
  if (!values.title) return getSkillsData();
  if (data.id) {
    await db.update(courses).set(values).where(eq(courses.id, data.id));
  } else {
    await db.insert(courses).values(values);
  }
  return getSkillsData();
}

export async function deleteCourse(id: number): Promise<SkillsData> {
  await db.delete(courses).where(eq(courses.id, id));
  return getSkillsData();
}

export async function upsertCert(data: {
  id?: number;
  name: string;
  status?: string;
  targetDate?: string;
  notes?: string;
}): Promise<SkillsData> {
  const values = {
    name: data.name.trim(),
    status: data.status ?? "planned",
    targetDate: data.targetDate ?? "",
    notes: data.notes ?? "",
  };
  if (!values.name) return getSkillsData();
  if (data.id) {
    await db.update(certs).set(values).where(eq(certs.id, data.id));
  } else {
    await db.insert(certs).values(values);
  }
  return getSkillsData();
}

export async function deleteCert(id: number): Promise<SkillsData> {
  await db.delete(certs).where(eq(certs.id, id));
  return getSkillsData();
}

export async function addCtf(data: {
  eventName: string;
  platform?: string;
  challengesSolved?: number;
  points?: number;
  date?: string;
  notes?: string;
}): Promise<SkillsData> {
  if (data.eventName.trim()) {
    await db.insert(ctfEvents).values({
      eventName: data.eventName.trim(),
      platform: data.platform ?? "",
      challengesSolved: data.challengesSolved ?? 0,
      points: data.points ?? 0,
      date: data.date ?? "",
      notes: data.notes ?? "",
    });
  }
  return getSkillsData();
}

export async function deleteCtf(id: number): Promise<SkillsData> {
  await db.delete(ctfEvents).where(eq(ctfEvents.id, id));
  return getSkillsData();
}

export async function logCoding(data: {
  date: string;
  problemsSolved: number;
  platform?: string;
}): Promise<SkillsData> {
  if (data.problemsSolved > 0) {
    await db.insert(codingLogs).values({
      date: data.date,
      problemsSolved: Math.round(data.problemsSolved),
      platform: data.platform ?? "",
    });
  }
  return getSkillsData();
}

export async function deleteCodingLog(id: number): Promise<SkillsData> {
  await db.delete(codingLogs).where(eq(codingLogs.id, id));
  return getSkillsData();
}

const CYBER_TEMPLATE: { domain: string; name: string }[] = [
  { domain: "networking", name: "TCP/IP & the OSI model" },
  { domain: "networking", name: "Subnetting & routing basics" },
  { domain: "networking", name: "Wireshark traffic analysis" },
  { domain: "web security", name: "OWASP Top 10 (hands-on)" },
  { domain: "web security", name: "Burp Suite workflow" },
  { domain: "web security", name: "SQLi / XSS / IDOR labs" },
  { domain: "linux", name: "Bash & shell scripting" },
  { domain: "linux", name: "Linux privilege escalation" },
  { domain: "crypto", name: "Symmetric vs asymmetric crypto" },
  { domain: "crypto", name: "Hashing, salting & password attacks" },
  { domain: "reversing & pwn", name: "x86 assembly reading" },
  { domain: "reversing & pwn", name: "Buffer overflows (pwn)" },
  { domain: "blue team", name: "Log analysis & SIEM basics" },
  { domain: "blue team", name: "Incident response process" },
  { domain: "coding", name: "Python for tooling & scripting" },
  { domain: "coding", name: "Data structures & algorithms" },
];

export async function seedSkillTemplate(): Promise<SkillsData> {
  const existing = await db.select({ id: skills.id }).from(skills).limit(1);
  if (existing.length === 0) {
    await db.insert(skills).values(
      CYBER_TEMPLATE.map((t) => ({
        domain: t.domain,
        name: t.name,
        status: "learning" as const,
        progress: 0,
      }))
    );
    await db.insert(certs).values([
      { name: "CompTIA Security+", status: "studying" as const, notes: "First cert on the path." },
      { name: "PNPT or CySA+", status: "planned" as const, notes: "Mid-level proof of skill." },
      { name: "OSCP", status: "planned" as const, notes: "The long game. Try harder." },
    ]);
  }
  return getSkillsData();
}
