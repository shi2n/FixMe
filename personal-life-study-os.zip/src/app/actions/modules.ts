"use server";

import { db } from "@/db";
import {
  goals,
  applications,
  resumeVersions,
  transactions,
  financeSettings,
} from "@/db/schema";
import { desc, eq, like } from "drizzle-orm";
import type {
  ApplicationData,
  FinanceSettingsData,
  GoalData,
  ResumeData,
  TransactionData,
} from "@/lib/types";

// ------------------------------ career ------------------------------

export interface CareerData {
  goals: GoalData[];
  applications: ApplicationData[];
  resumes: ResumeData[];
}

export async function getCareer(): Promise<CareerData> {
  const g = await db.select().from(goals).orderBy(desc(goals.createdAt));
  const a = await db
    .select()
    .from(applications)
    .orderBy(desc(applications.updatedAt));
  const r = await db
    .select()
    .from(resumeVersions)
    .orderBy(desc(resumeVersions.createdAt));
  return {
    goals: g.map((x) => ({
      id: x.id,
      title: x.title,
      area: x.area ?? "career",
      targetDate: x.targetDate ?? "",
      status: x.status ?? "active",
      notes: x.notes ?? "",
    })),
    applications: a.map((x) => ({
      id: x.id,
      company: x.company,
      role: x.role ?? "",
      kind: x.kind ?? "internship",
      stage: x.stage ?? "applied",
      link: x.link ?? "",
      skillsRequired: x.skillsRequired ?? "",
      prepNotes: x.prepNotes ?? "",
      appliedAt: x.appliedAt ?? "",
    })),
    resumes: r.map((x) => ({
      id: x.id,
      label: x.label,
      notes: x.notes ?? "",
      createdAt: x.createdAt?.toISOString() ?? "",
    })),
  };
}

export async function addGoal(data: {
  title: string;
  area?: string;
  targetDate?: string;
  notes?: string;
}): Promise<CareerData> {
  if (data.title.trim()) {
    await db.insert(goals).values({
      title: data.title.trim(),
      area: data.area ?? "career",
      targetDate: data.targetDate ?? "",
      notes: data.notes ?? "",
    });
  }
  return getCareer();
}

export async function updateGoal(
  id: number,
  patch: Partial<Pick<GoalData, "title" | "status" | "notes" | "targetDate">>
): Promise<CareerData> {
  await db.update(goals).set(patch).where(eq(goals.id, id));
  return getCareer();
}

export async function deleteGoal(id: number): Promise<CareerData> {
  await db.delete(goals).where(eq(goals.id, id));
  return getCareer();
}

export async function addApplication(data: {
  company: string;
  role?: string;
  kind?: string;
  stage?: string;
  link?: string;
  skillsRequired?: string;
  prepNotes?: string;
  appliedAt?: string;
}): Promise<CareerData> {
  if (data.company.trim()) {
    await db.insert(applications).values({
      company: data.company.trim(),
      role: data.role ?? "",
      kind: data.kind ?? "internship",
      stage: data.stage ?? "applied",
      link: data.link ?? "",
      skillsRequired: data.skillsRequired ?? "",
      prepNotes: data.prepNotes ?? "",
      appliedAt: data.appliedAt ?? "",
    });
  }
  return getCareer();
}

export async function updateApplication(
  id: number,
  patch: Partial<
    Pick<
      ApplicationData,
      "company" | "role" | "stage" | "link" | "skillsRequired" | "prepNotes" | "appliedAt" | "kind"
    >
  >
): Promise<CareerData> {
  await db
    .update(applications)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(applications.id, id));
  return getCareer();
}

export async function deleteApplication(id: number): Promise<CareerData> {
  await db.delete(applications).where(eq(applications.id, id));
  return getCareer();
}

export async function addResume(data: {
  label: string;
  notes?: string;
}): Promise<CareerData> {
  if (data.label.trim()) {
    await db
      .insert(resumeVersions)
      .values({ label: data.label.trim(), notes: data.notes ?? "" });
  }
  return getCareer();
}

export async function deleteResume(id: number): Promise<CareerData> {
  await db.delete(resumeVersions).where(eq(resumeVersions.id, id));
  return getCareer();
}

// ------------------------------ finance ------------------------------

export interface FinanceData {
  settings: FinanceSettingsData;
  transactions: TransactionData[]; // selected month
  month: string; // YYYY-MM
}

async function ensureFinanceSettings(): Promise<FinanceSettingsData> {
  const rows = await db.select().from(financeSettings).limit(1);
  const r = rows[0];
  if (r) {
    return {
      savingsGoalName: r.savingsGoalName ?? "",
      savingsGoalAmount: r.savingsGoalAmount ?? 0,
      savedSoFar: r.savedSoFar ?? 0,
      monthlyBudget: r.monthlyBudget ?? 0,
      currency: r.currency ?? "$",
    };
  }
  await db.insert(financeSettings).values({});
  return {
    savingsGoalName: "",
    savingsGoalAmount: 0,
    savedSoFar: 0,
    monthlyBudget: 0,
    currency: "$",
  };
}

export async function getFinance(month: string): Promise<FinanceData> {
  const s = await ensureFinanceSettings();
  const rows = await db
    .select()
    .from(transactions)
    .where(like(transactions.date, `${month}%`))
    .orderBy(desc(transactions.date));
  return {
    settings: s,
    month,
    transactions: rows.map((t) => ({
      id: t.id,
      kind: t.kind,
      amount: t.amount,
      category: t.category ?? "misc",
      note: t.note ?? "",
      date: t.date,
    })),
  };
}

export async function addTransaction(data: {
  kind: string;
  amount: number;
  category?: string;
  note?: string;
  date: string;
}): Promise<FinanceData> {
  if (data.amount > 0 && (data.kind === "income" || data.kind === "expense")) {
    await db.insert(transactions).values({
      kind: data.kind,
      amount: data.amount,
      category: data.category ?? "misc",
      note: data.note ?? "",
      date: data.date,
    });
  }
  return getFinance(data.date.slice(0, 7));
}

export async function deleteTransaction(
  id: number,
  month: string
): Promise<FinanceData> {
  await db.delete(transactions).where(eq(transactions.id, id));
  return getFinance(month);
}

export async function saveFinanceSettings(
  patch: Partial<FinanceSettingsData>
): Promise<FinanceSettingsData> {
  const rows = await db.select().from(financeSettings).limit(1);
  if (rows[0]) {
    await db
      .update(financeSettings)
      .set(patch)
      .where(eq(financeSettings.id, rows[0].id));
  } else {
    await db.insert(financeSettings).values(patch);
  }
  return ensureFinanceSettings();
}
