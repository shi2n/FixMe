import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

// ---------- single-user profile ----------
export const profile = pgTable("profile", {
  id: serial("id").primaryKey(),
  name: text("name").default(""),
  age: integer("age"),
  gender: text("gender").default(""),
  country: text("country").default(""),
  city: text("city").default(""),
  timezone: text("timezone").default(""),
  heightCm: integer("height_cm"),
  typicalSleepHours: real("typical_sleep_hours").default(7.5),
  usualBedtime: text("usual_bedtime").default("23:00"),
  usualWakeTime: text("usual_wake_time").default("07:00"),
  educationLevel: text("education_level").default(""),
  focusAreas: text("focus_areas").default(""),
  existingSkills: text("existing_skills").default(""),
  skillGaps: text("skill_gaps").default(""),
  healthNotes: text("health_notes").default(""),
  badHabits: text("bad_habits").default(""),
  motivationStyle: text("motivation_style").default("balanced"), // tough | gentle | balanced
  onboarded: boolean("onboarded").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ---------- daily check-in ----------
export const checkins = pgTable("checkins", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(), // YYYY-MM-DD (local)
  sleepHours: real("sleep_hours"),
  sleepQuality: integer("sleep_quality"),
  bedtime: text("bedtime").default(""), // actual bedtime last night "HH:MM"
  mood: integer("mood"),
  energy: integer("energy"),
  emotionalLoad: text("emotional_load").default(""),
  illness: text("illness").default(""),
  studyMinutes: integer("study_minutes").default(0),
  exerciseDone: boolean("exercise_done").default(false),
  exerciseType: text("exercise_type").default(""),
  distraction: text("distraction").default(""),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ---------- career ----------
export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  area: text("area").default("career"),
  targetDate: text("target_date").default(""),
  status: text("status").default("active"), // active | done | dropped
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  company: text("company").notNull(),
  role: text("role").default(""),
  kind: text("kind").default("internship"), // job | internship
  stage: text("stage").default("applied"), // saved | applied | oa | interview | offer | rejected
  link: text("link").default(""),
  skillsRequired: text("skills_required").default(""),
  prepNotes: text("prep_notes").default(""),
  appliedAt: text("applied_at").default(""),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const resumeVersions = pgTable("resume_versions", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

// ---------- finance ----------
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(), // income | expense
  amount: real("amount").notNull(),
  category: text("category").default("misc"),
  note: text("note").default(""),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const financeSettings = pgTable("finance_settings", {
  id: serial("id").primaryKey(),
  savingsGoalName: text("savings_goal_name").default(""),
  savingsGoalAmount: real("savings_goal_amount").default(0),
  savedSoFar: real("saved_so_far").default(0),
  monthlyBudget: real("monthly_budget").default(0),
  currency: text("currency").default("$"),
});

// ---------- skills / cybersecurity ----------
export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  domain: text("domain").default("general"),
  name: text("name").notNull(),
  status: text("status").default("learning"), // planned | learning | practicing | solid
  progress: integer("progress").default(0), // 0-100
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  platform: text("platform").default(""),
  status: text("status").default("in-progress"), // planned | in-progress | done
  progress: integer("progress").default(0),
  url: text("url").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const certs = pgTable("certs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").default("planned"), // planned | studying | scheduled | earned
  targetDate: text("target_date").default(""),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const ctfEvents = pgTable("ctf_events", {
  id: serial("id").primaryKey(),
  eventName: text("event_name").notNull(),
  platform: text("platform").default(""),
  challengesSolved: integer("challenges_solved").default(0),
  points: integer("points").default(0),
  date: text("date").default(""),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const codingLogs = pgTable("coding_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  problemsSolved: integer("problems_solved").default(0),
  platform: text("platform").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

// ---------- mistake log ----------
export const mistakes = pgTable("mistakes", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  title: text("title").notNull(),
  category: text("category").default("other"), // deadline | test | wasted-day | procrastination | other
  cause: text("cause").default(""),
  fix: text("fix").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

// ---------- reading list ----------
export const books = pgTable("books", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  author: text("author").default(""),
  category: text("category").default("personal"), // cyber | cs | personal
  why: text("why").default(""),
  status: text("status").default("to-read"), // to-read | reading | done
  source: text("source").default("manual"), // manual | curated | ai
  createdAt: timestamp("created_at").defaultNow(),
});

// ---------- notes & practice ----------
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  kind: text("kind").default("note"), // note | practice
  title: text("title").default(""),
  content: text("content").default(""),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ---------- app settings (AI provider, nudges) ----------
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  provider: text("provider").default("none"), // none | openai | anthropic | gemini
  apiKeyEnc: text("api_key_enc"), // AES-256-GCM encrypted, never leaves the server
  nudgesEnabled: boolean("nudges_enabled").default(false),
  studyNudgeTime: text("study_nudge_time").default("17:00"),
  capNudges: boolean("cap_nudges").default(true),
  exerciseNudgeTime: text("exercise_nudge_time").default(""),
  readingNudgeTime: text("reading_nudge_time").default(""),
});
